package Exercicio11;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		// Coletar hora conforme esta configurado no sistema

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy hh:mm");
		System.out.println("Ola, hoje sao: " + sdf.format(new Date()));

		// Utilizando o Scanner para o usuario digitar as etapas do menu.

		int nOpc = -1;
		Scanner ler = new Scanner(System.in);

		// Criando um novo objeto ControleRemoto chamado CONT[] para tambem realizar a
		// funcao do controle do Menu pois, foi definido 6 etapas do menu.

		ControleRemoto cont[] = new ControleRemoto[1];

		// Iniciando no canal 1, volume 20 e bateria 100%.

		cont[0] = new ControleRemoto(nOpc, nOpc, nOpc);

		// Criando o Menu com 6 etapas utilizando SOMENTE os GET & Setters dos valores
		// ja predefinidos na classe ControladorTVeControleRemoto que é uma heranca
		// da classe ControleRemoto e Televisao.

		while (true) {
			pintaMenu();
			nOpc = ler.nextInt();
			if (nOpc == 0)
				break;

			System.out.printf("\n\n");
			switch (nOpc) {
			case 1:
				cont[0].Canal(1);
				break;
			case 2:
				cont[0].Canal(0);
				break;
			case 3:
				System.out.printf("\nInsira o canal: ");
				cont[0].setCanal(ler.nextInt());
				break;
			case 4:
				cont[0].Volume(1);
				break;
			case 5:
				cont[0].Volume(0);
				break;
			case 6:
				System.out.printf("Volume: %d\n", cont[0].getVolume());
				System.out.printf("Canal: %d\n", cont[0].getCanal());
				System.out.printf("A carga bateria esta em: " + cont[0].getbBateria());
				// Esperando 2 segundos
				try {
					Thread.sleep(2000);
				} catch (InterruptedException ex) {
				}
				break;
			default:
				System.out.printf("\n Valor Incorreto");
				// Esperando 2 segundos
				try {
					Thread.sleep(2000);
				} catch (InterruptedException ex) {
				}
				break;
			}
		}
		System.out.printf("\n OFF TV! See you soon. /o/ \n");
	}

	private static void pintaMenu() {
		System.out.printf("\n\n > Menu do Controle Remoto:");
		System.out.printf("\n __________________________");
		System.out.printf("\n  1- + Canal ");
		System.out.printf("\n  2- - Canal ");
		System.out.printf("\n  3- * Pesquisar canal ");
		System.out.printf("\n  4- + Volume ");
		System.out.printf("\n  5- - Volume ");
		System.out.printf("\n  6- @ Mostrar informacoes ");
		System.out.printf("\n  0- x Sair ");
		System.out.printf("\n __________________________");
		System.out.printf("\n > Resultado: ");
	}
}
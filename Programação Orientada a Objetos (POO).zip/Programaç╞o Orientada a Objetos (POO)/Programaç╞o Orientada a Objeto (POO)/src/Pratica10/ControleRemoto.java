package Exercicio11;

public class ControleRemoto extends ControladorTVeControle {

	// Constructor

	public ControleRemoto(int nC, int nV, int bB) {
		super(nC, nV, bB);
	}
}
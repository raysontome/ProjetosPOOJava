package Exercicio11;

public class Televisao extends ControladorTVeControle {

	// Constructor

	public Televisao(int nC, int nV, int bB) {
		super(nC, nV, bB);
	}
}
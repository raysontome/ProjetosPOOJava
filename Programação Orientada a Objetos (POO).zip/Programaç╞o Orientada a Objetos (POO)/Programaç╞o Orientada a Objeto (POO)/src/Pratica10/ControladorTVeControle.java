package Exercicio11;

public class ControladorTVeControle {

	// Atributos

	private int nCanal, nVolume, bBateria;

	// Constructor

	public ControladorTVeControle(int nC, int nV, int bB) {
		this.nCanal = 1;
		this.nVolume = 20;
		this.bBateria = 100;
	}

	// Getters & Setters

	public int getCanal() {
		return this.nCanal;
	}

	public void setCanal(int nCa) {
		if ((nCa >= 1) || (nCa <= 200)) {
			this.nCanal = nCa;
		}
	}

	public int getVolume() {
		return nVolume;
	}

	public void setVolume(int volume) {
		nVolume = volume;
	}

	public int getbBateria() {
		return bBateria;
	}

	public void setbBateria(int bBateria) {
		this.bBateria = bBateria;
	}

	// Metodos

	// Mudar Canal
	public void Canal(int nTipo) {
		// + (Aumenta Canal)
		if (nTipo == 1) {
			// Se for menor que 200, aumenta
			if (this.nCanal < 200) {
				this.nCanal += 1;
			}
			// Volta pro 1
			else {
				this.nCanal = 1;
			}
		}

		// - (Diminui Canal)
		else {
			// Se for maior que 1, diminuir
			if (this.nCanal > 1) {
				this.nCanal -= 1;
			}
			// Volta pro 200
			else {
				this.nCanal = 200;
			}
		}
	}

	public void Volume(int i) {
		// + (Aumenta Volume)
		if (i == 1) {
			// Se for menor que 100
			if (this.nVolume < 100) {
				this.nVolume++;
			}
		}
		// - (Diminui Volume)
		else {
			// Se for maior que 0
			if (this.nVolume > 0) {
				this.nVolume--;
			}
		}
	}
}
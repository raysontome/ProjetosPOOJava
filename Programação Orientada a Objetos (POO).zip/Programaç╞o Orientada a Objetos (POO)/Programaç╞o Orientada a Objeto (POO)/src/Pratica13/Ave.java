package Exercicio16;

public abstract class Ave extends Animal {

	// Metodos

	@Override
	public void emitirSom() {
	}

	public void voar() {

	}
}
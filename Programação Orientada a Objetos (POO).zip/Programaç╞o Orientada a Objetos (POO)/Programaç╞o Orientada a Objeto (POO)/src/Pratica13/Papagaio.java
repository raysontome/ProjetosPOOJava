package Exercicio16;

public class Papagaio extends Ave implements AnimalDomesticado {

	// Metodos

	@Override
	public void emitirSom() {
	}

	@Override
	public void voar() {
	}

	@Override
	public void alimentar() {
	}

	@Override
	public void levarveterinario() {
	}

	@Override
	public void chamarveterinario() {
	}
}
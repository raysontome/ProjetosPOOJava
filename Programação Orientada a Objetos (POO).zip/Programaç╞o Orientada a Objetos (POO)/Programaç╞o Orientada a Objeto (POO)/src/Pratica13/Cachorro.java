package Exercicio16;

public class Cachorro extends Mamifero implements AnimalDomesticado {

	// Metodos

	@Override
	public void alimentar() {

	}

	@Override
	public void levarveterinario() {

	}

	@Override
	public void chamarveterinario() {

	}

	@Override
	public void emitirSom() {

	}
}
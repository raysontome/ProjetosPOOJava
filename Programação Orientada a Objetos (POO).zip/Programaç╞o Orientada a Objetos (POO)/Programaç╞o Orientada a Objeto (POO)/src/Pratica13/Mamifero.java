package Exercicio16;

public abstract class Mamifero extends Animal {

	// Metodos

	public void amamentar() {

	}
}
package Exercicio16;

public abstract class Animal {

	// Atributos

	private String nome;

	// Metodos
	
	public abstract void emitirSom();

	// Getters & Setters
	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
}
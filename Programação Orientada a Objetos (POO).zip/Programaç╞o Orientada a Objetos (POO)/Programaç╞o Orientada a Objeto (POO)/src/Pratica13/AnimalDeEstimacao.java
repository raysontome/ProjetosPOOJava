package Exercicio16;

public abstract interface AnimalDeEstimacao {

	// Metodos

	public abstract void brincar();

	public abstract void levarPassear();
}
package Exercicio16;

public abstract interface AnimalDomesticado {

	// Metodos

	public abstract void alimentar();

	public abstract void levarveterinario();

	public abstract void chamarveterinario();
}
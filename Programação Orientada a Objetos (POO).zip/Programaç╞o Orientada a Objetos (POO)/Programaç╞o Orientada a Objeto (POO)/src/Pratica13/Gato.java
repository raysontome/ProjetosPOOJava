package Exercicio16;

public class Gato extends Mamifero implements AnimalDeEstimacao {

	// Metodos

	@Override
	public void brincar() {

	}

	@Override
	public void levarPassear() {

	}

	@Override
	public void emitirSom() {

	}
}
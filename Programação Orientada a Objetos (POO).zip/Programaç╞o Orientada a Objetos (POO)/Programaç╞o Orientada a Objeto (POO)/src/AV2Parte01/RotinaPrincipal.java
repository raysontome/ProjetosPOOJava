package Exercicio20AV2Part1;

public class RotinaPrincipal {

	public static void main(String[] args) {

		Agente N01Agente = new Agente(123456, "Lucas", 2019, true);
		Agente N02Agente = new Agente(7891011, "Johan", 2019, true);
		Agente N03Agente = new Agente(12131415, "Arthur", 2019, true);

		Motorista motorista = new Motorista(1713375, "Rayson Tome", 2019, true);

		Viatura viatura = new Viatura("ABCDE-2458", true);

		Destino destino = new Destino("AV. Cesar Cals, n 1231 / Praia do Futuro", true);

		FormacaoEquipe Equipe01 = new FormacaoEquipe();

		Equipe01.equipeFormada(motorista, destino, N01Agente, viatura);
		Equipe01.equipeFormada(motorista, destino, N01Agente, N02Agente, viatura);
		Equipe01.equipeFormarda(motorista, destino, N01Agente, N02Agente, N03Agente, viatura);
	}
}
package Exercicio20AV2Part1;

abstract class Funcionario {

	// Atributos

	private int numMatricula;
	private int anodeAdmissao;
	private String nome;

	// Constructor

	public Funcionario(int matricula, String nome, int ano) {
		this.setNumMatricula(matricula);
		this.setNome(nome);
		this.setAnoDeAdmicao(ano);
	}

	// Encapsulamento

	public int getNumMatricula() {
		return numMatricula;
	}

	public void setNumMatricula(int numMatricula) {
		this.numMatricula = numMatricula;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getAnoDeAdmicao() {
		return anodeAdmissao;
	}

	public void setAnoDeAdmicao(int anoDeAdmicao) {
		this.anodeAdmissao = anoDeAdmicao;
	}
}
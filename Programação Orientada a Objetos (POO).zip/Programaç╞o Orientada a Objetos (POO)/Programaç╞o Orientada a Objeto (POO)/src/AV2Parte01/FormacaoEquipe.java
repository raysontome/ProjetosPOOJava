package Exercicio20AV2Part1;

public class FormacaoEquipe {

	// Metodos Personalizados

	public void equipeFormada(Motorista motor, Destino dest, Agente agen, Viatura viat) {
		if (motor.getAssociado() == true && dest.getAssociado() == true && agen.getAssociado() == true
				&& viat.getAssociado() == true) {
			System.out.println("Motorista");
			System.out.println("Nome: " + motor.getNome() + "\n" + "Matricula: " + motor.getNumMatricula() + "\n"
					+ "Ano de Admissao: " + motor.getAnoDeAdmicao());
			System.out.println("--------------------------------------");
			System.out.println("Agente");
			System.out.println("Nome: " + agen.getNome() + "\n" + "Matricula: " + agen.getNumMatricula() + "\n"
					+ "Ano de Admissao: " + agen.getAnoDeAdmicao());
			System.out.println("Destino: " + dest.getDestino());
			System.out.println("--------------------------------------");
			System.out.println("Viatura");
			System.out.println("Placa do veiculo: " + viat.getPlaca());
			System.out.println("--------------------------------------");
		}

		// Verificacao

		if (motor.getAssociado() == false) {
			System.out.println("O Motorista atualmente faz parte de outra equipe!");
		}
		if (dest.getAssociado() == false) {
			System.out.println("O Destino esta associado a outra equipe!");
		}
		if (agen.getAssociado() == false) {
			System.out.println("O Agente esta associado a outra equipe!");
		}
		if (viat.getAssociado() == false) {
			System.out.println("A Viatura esta associado a outra equipe!");
		}
	}

	// Formacao de Equipe com Agente 1 e Agente 2

	public void equipeFormada(Motorista mot, Destino dest, Agente N1Agente, Agente N2Agente, Viatura viatura) {
		if (mot.getAssociado() == true && dest.getAssociado() == true && N1Agente.getAssociado() == true
				&& N2Agente.getAssociado() == true && viatura.getAssociado() == true) {
			System.out.println("Motorista");
			System.out.println("Nome: " + mot.getNome() + "\n" + "Matricula: " + mot.getNumMatricula() + "\n"
					+ "Ano de Admissao " + mot.getAnoDeAdmicao());
			System.out.println("--------------------------------------");
			System.out.println("N1 Agente");
			System.out.println("Nome: " + N1Agente.getNome() + "\n" + "Matricula: " + N1Agente.getNumMatricula() + "\n"
					+ "Ano de Admissao " + N1Agente.getAnoDeAdmicao());
			System.out.println("--------------------------------------");
			System.out.println("N2 Agente");
			System.out.println("Nome: " + N2Agente.getNome() + "\n" + "Matricula: " + N2Agente.getNumMatricula() + "\n"
					+ "Ano de Admissao " + N2Agente.getAnoDeAdmicao());
			System.out.println("Destino: " + dest.getDestino());
			System.out.println("--------------------------------------");
			System.out.println("Viatura");
			System.out.println("Placa do Veiculo: " + viatura.getPlaca());
			System.out.println("--------------------------------------");

			// Verificacao

		}
		if (mot.getAssociado() == false) {
			System.out.println("O Motorista atualmente faz parte de outra equipe!");
		}
		if (dest.getAssociado() == false) {
			System.out.println("O Destino esta associado a outra equipe!");
		}
		if (viatura.getAssociado()) {
			System.out.println("A Viatura esta associado a outra equipe!");
		}
		if (N1Agente.getAssociado() == false) {
			System.out.println("O N1Agente esta associado a outra equipe!");
		}
		if (N2Agente.getAssociado() == false) {
			System.out.println("O N2Agente esta associado a outra equipe!");
		}
		if (viatura.getAssociado() == false) {
			System.out.println("A Viatura esta associada a outra equipe!");
		}
	}

	// Formacao de Equipe com Agente 1, Agente 2 e Agente 3

	public void equipeFormarda(Motorista mot, Destino dest, Agente N1Agente, Agente N2Agente, Agente N3Agente,
			Viatura viatura) {
		if (mot.getAssociado() == true && dest.getAssociado() == true && N1Agente.getAssociado() == true
				&& N2Agente.getAssociado() == true && N3Agente.getAssociado() == true
				&& viatura.getAssociado() == true) {
			System.out.println("Motorista");
			System.out.println("Nome: " + mot.getNome() + "\n" + "Matricula: " + mot.getNumMatricula() + "\n"
					+ "Ano de Admissao: " + mot.getAnoDeAdmicao());
			System.out.println("--------------------------------------");
			System.out.println("N1 Agente");
			System.out.println("Nome: " + N1Agente.getNome() + "\n" + "Matricula: " + N1Agente.getNumMatricula() + "\n"
					+ "Ano de Admissao: " + N1Agente.getAnoDeAdmicao());
			System.out.println("--------------------------------------");
			System.out.println("N2 Agente");
			System.out.println("Nome: " + N2Agente.getNome() + "\n" + "matricula: " + N2Agente.getNumMatricula() + "\n"
					+ "Ano de Admissao: " + N2Agente.getAnoDeAdmicao());
			System.out.println("--------------------------------------");
			System.out.println("N3 Agente");
			System.out.println("Nome: " + N3Agente.getNome() + "\n" + "Matricula: " + N3Agente.getNumMatricula() + "\n"
					+ "Ano de Admissao: " + N3Agente.getAnoDeAdmicao());
			System.out.println("Destino: " + dest.getDestino());
			System.out.println("--------------------------------------");
			System.out.println("Viatura");
			System.out.println("Placa do Veiculo: " + viatura.getPlaca());
			System.out.println("--------------------------------------");
		}

		// Verificacao

		if (mot.getAssociado() == false) {
			System.out.println("O Motorista esta associado a outra equipe!");
		}
		if (dest.getAssociado() == false) {
			System.out.println("O Destino esta associado a outra equipe!");
		}
		if (viatura.getAssociado()) {
			System.out.println("A Viatura esta associada a outra equipe!");
		}
		if (N1Agente.getAssociado() == false) {
			System.out.println("O N1Agente esta associado a outra equipe!");
		}
		if (N2Agente.getAssociado() == false) {
			System.out.println("O N2Agente esta associado a outra equipe!");
		}
		if (N3Agente.getAssociado() == false) {
			System.out.println(" O N3Agente esta associada a outra equipe!");
		}
		if (viatura.getAssociado() == false) {
			System.out.println("A Viatura esta associada a outra equipe!");
		}
	}
}
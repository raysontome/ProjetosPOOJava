package Exercicio20AV2Part1;

public class Viatura {

	// Atributos

	private String placa;
	private boolean associado;

	// Constructor

	Viatura(String plac, boolean asso) {
		this.setPlaca(plac);
		this.setAssociado(asso);
	}

	// Encapsulamento

	public String getPlaca() {
		return placa;
	}

	public void setPlaca(String placa) {
		this.placa = placa;
	}

	public boolean getAssociado() {
		return associado;
	}

	public void setAssociado(boolean associado) {
		this.associado = associado;
	}
}
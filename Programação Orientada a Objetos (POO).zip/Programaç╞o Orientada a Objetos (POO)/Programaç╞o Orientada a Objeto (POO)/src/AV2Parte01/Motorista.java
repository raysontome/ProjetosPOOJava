package Exercicio20AV2Part1;

public class Motorista extends Funcionario {
	// Atributos

	private boolean associado;

	// Constructor

	public Motorista(int matricula, String nome, int ano, boolean associado) {

		super(matricula, nome, ano);
		this.setAssociado(associado);
	}

	// Encapsulamento

	public boolean getAssociado() {
		return associado;
	}

	public void setAssociado(boolean associado) {
		this.associado = associado;
	}
}
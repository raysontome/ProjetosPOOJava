package Exercicio20AV2Part1;

public class Destino {

	// Atributos

	private String destino;
	private boolean associado;

	// Constructor

	Destino(String dest, boolean asso) {
		this.setDestino(dest);
		this.setAssociado(asso);
	}

	// Encapsulamento

	public String getDestino() {
		return destino;
	}

	public void setDestino(String destino) {
		this.destino = destino;
	}

	public boolean getAssociado() {
		return associado;
	}

	public void setAssociado(boolean associado) {
		this.associado = associado;
	}
}
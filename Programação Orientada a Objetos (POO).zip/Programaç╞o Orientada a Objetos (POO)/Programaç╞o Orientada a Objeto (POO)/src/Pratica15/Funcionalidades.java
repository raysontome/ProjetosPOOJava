package Exercicio18;

public abstract interface Funcionalidades {

	abstract void ligar();

	abstract void desligar();

	abstract void dirigir();

	abstract void estacionar();

	abstract void durabilidade();
}
package Exercicio18;

public class Ocorrencia {

	// Reduzir a durabilidade do veiculo em 20% por ocorrencia;
	// Imprimir quando um veiculo deu "PT";
	// Instanciando os objetos

	public Ocorrencia(Veiculo veiculo01, Veiculo veiculo02) {
		veiculo01.setDurabilidade(veiculo01.getDurabilidade() - veiculo01.getDurabilidade());
		System.out.println("Veiculo deu PT!");

	}

	public Ocorrencia(Veiculo veiculo03, Veiculo veiculo04, Veiculo veiculo05) {
	}
}
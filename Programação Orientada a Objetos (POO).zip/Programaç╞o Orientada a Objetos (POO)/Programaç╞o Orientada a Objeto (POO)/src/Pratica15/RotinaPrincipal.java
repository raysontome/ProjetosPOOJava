package Exercicio18;

public class RotinaPrincipal {

	public static void main(String[] args) {

		// Instanciando os objetos

		Veiculo veiculo01 = new Veiculo("ABC", "CBA", "FIAT");
		Veiculo veiculo02 = new Veiculo("DEF", "FED", "COROLLA");
		Veiculo veiculo03 = new Veiculo("FGH", "HGF", "CHEVROLET");
		Veiculo veiculo04 = new Veiculo("IJK", "KJI", "FORD");
		Veiculo veiculo05 = new Veiculo("LMN", "NML", "BMW");
	}
}
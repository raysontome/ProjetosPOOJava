package Exercicio18;

public abstract interface Reformar {

	abstract void rebaixar();

	abstract void consertar();

	abstract void mudarCor();
}
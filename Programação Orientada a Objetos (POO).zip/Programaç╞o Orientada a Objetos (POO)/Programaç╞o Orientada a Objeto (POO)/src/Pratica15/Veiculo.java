package Exercicio18;

public class Veiculo implements Funcionalidades, Reformar {

	// Atributos

	private String placa, chassi, marca;
	private int durabilidade;

	// Metodos Abstratos

	@Override
	public void ligar() {
		System.out.println("Veiculo ligado!");
	}

	@Override
	public void desligar() {
		System.out.println("Veiculo desligado!");
	}

	@Override
	public void dirigir() {
		System.out.println("Veiculo dirigindo!");
	}

	@Override
	public void estacionar() {
		System.out.println("Veiculo estacionado!");
	}

	@Override
	public void durabilidade() {
		System.out.println("Veiculo durabilidade!");
		// 0 a 100//
	}

	@Override
	public void rebaixar() {
		System.out.println("Veiculo rebaixado!");
	}

	@Override
	public void consertar() {
		System.out.println("Veiculo consertado!");
	}

	@Override
	public void mudarCor() {
		System.out.println("Veiculo de cor alterado!");
	}

	// Getters & Setters

	public String getPlaca() {
		return placa;
	}

	public void setPlaca(String placa) {
		this.placa = placa;
	}

	public String getChassi() {
		return chassi;
	}

	public void setChassi(String chassi) {
		this.chassi = chassi;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public int getDurabilidade() {
		return durabilidade;
	}

	public void setDurabilidade(int durabilidade) {
		this.durabilidade = durabilidade;
	}

	// Constructor

	public Veiculo(String placa, String chassi, String marca) {
		this.setPlaca(placa);
		this.setChassi(chassi);
		this.setMarca(marca);
		this.setDurabilidade(100);
	}
}
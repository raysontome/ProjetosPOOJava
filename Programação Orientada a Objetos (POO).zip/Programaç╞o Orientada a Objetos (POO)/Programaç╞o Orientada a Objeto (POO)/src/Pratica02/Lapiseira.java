package Exercicio02;

public class Lapiseira {

	// Atributos

	private String Modelo;
	private String Cor;
	private int Ponta;
	private boolean ProntaEscrever;

	// Metodos

	public void escrever() {
		if (ProntaEscrever == true) {
			System.out.println("Estou escrevendo");
		}
	}

	public void sacarPonta() {
		ProntaEscrever = true;
	}

	public void Escrever() {

		if (ProntaEscrever == true)
			;
		System.out.println("Escrever");

	}

	public void recolherPonta() {
		ProntaEscrever = false;
	}

	public void status() {
		System.out.printf("Modelo: %s Cor: %s ponta: %d prontaEscrever: %b", Modelo, Cor, Ponta, ProntaEscrever);
	}

	// Getters & Setters

	public String getModelo() {
		return Modelo;
	}

	public void setModelo(String modelo) {
		this.Modelo = modelo;
	}

	public String getCor() {
		return Cor;
	}

	public void setCor(String cor) {
		this.Cor = cor;
	}

	public int getPonta() {
		return Ponta;
	}

	public void setPonta(int ponta) {
		this.Ponta = ponta;
	}

	public boolean isProntaEscrever() {
		return ProntaEscrever;
	}

	public void setProntaEscrever(boolean prontaEscrever) {
		this.ProntaEscrever = prontaEscrever;
	}
}
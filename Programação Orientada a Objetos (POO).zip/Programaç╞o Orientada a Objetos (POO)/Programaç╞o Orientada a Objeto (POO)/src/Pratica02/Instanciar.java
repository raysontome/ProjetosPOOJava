package Exercicio02;

public class Instanciar {
	public static void main(String[] args) {

		// Rotina Principal

		Lapiseira L1 = new Lapiseira();
		L1.setCor("AZUL");
		L1.setModelo("bic");
		L1.setPonta(05);
		L1.setProntaEscrever(true);
		L1.Escrever();
		L1.status();
	}
}
package Exercicio06;

public class RotinaPrincipal {

	public static void main(String[] args) {

		// Instanciando outros objetos

		Estacionamento estacionamento = new Estacionamento(15, 10, 10, 5);
		Carro c1 = new Carro("XRV3050", "Azul", 18.00);
		Moto m1 = new Moto("XRV3051", "Vermelho", 20.00);

		// Logo Estacionamento

		System.out.println("#Bem vindo ao Estacionamento da Unifor#");

		System.out.println("___________________________________________________________________________________");

		// VagasTotais atuais do Estacionamento (Carros e Motos) e Precos por Hora
		// (Carros e Motos)

		System.out.println("#VAGAS#");

		System.out.println(
				"O total de vagas para carros que encontram-se disponiveis é de: " + estacionamento.getNVagasCarro());
		System.out.println(
				"O preco para estacionar seu carro é de: R$" + estacionamento.getValorHoraCarro() + " por hora.");
		System.out.println(
				"O preco para estacionar sua moto é de: R$" + estacionamento.getValorHoraMoto() + " por hora.");
		System.out.println(
				"O total de vagas para motos que encontram-se disponiveis é de: " + estacionamento.getNVagasMoto());
		System.out.println("___________________________________________________________________________________");

		// Estacionando Carro e Moto, Numero de Vagas Restantas do Estacionamento para
		// Estacionar Carros e Motos futuros

		System.out.println("#ESTACIONANDO#");

		System.out.println("O carro com a numeracao de placa a seguir esta estacionado com sucesso!" + "Placa: "
				+ c1.getPlaca() + " Horario: " + c1.getEntrada());
		estacionamento.Estacionar(c1, c1.getEntrada());
		System.out.println("A moto com a numeracao de placa a seguir esta estacionada com sucesso!" + "Placa: "
				+ m1.getPlaca() + " Ho[rario: " + m1.getEntrada());
		estacionamento.Estacionar(m1, m1.getEntrada());
		System.out.println("___________________________________________________________________________________");

		// Retirando (Carro e Moto) e Definindo valor a pagar de ambos

		System.out.println("#RETIRANDO EM HORARIOS UTEIS#");

		estacionamento.RetirarCarro(c1, 19.00);
		estacionamento.RetirarMoto(m1, 21.00);
		System.out.println("___________________________________________________________________________________");

		// Estacionamento Fechado Carro e Moto

		System.out.println("#FECHADO#");

		estacionamento.RetirarCarro(c1, 25);
		estacionamento.RetirarMoto(m1, 25);
		System.out.println("___________________________________________________________________________________");

		// Caixa total do Estacionamento Unifor - Carros e Motos

		System.out.println("O caixa total encontra-se com a quantia de: R$" + estacionamento.getTotalArrecadado());

		System.out.println("___________________________________________________________________________________");
	}
}
package Exercicio06;

public class Carro extends Veiculo {

	// Constructor

	public Carro(String placa, String cor, double d) {
		super(placa, cor, d);
	}
}
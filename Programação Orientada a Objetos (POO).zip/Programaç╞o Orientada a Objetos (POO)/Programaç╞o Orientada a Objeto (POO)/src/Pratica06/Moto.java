package Exercicio06;

public class Moto extends Veiculo {

	// Constructor

	public Moto(String placa, String cor, double d) {
		super(placa, cor, d);
	}
}
package Exercicio06;

public class Estacionamento {

	// Constructor
	public Estacionamento(int nVagasCarro, int nVagasMoto, double valorHoraCarro, double valorHoraMoto) {
		this.NVagasCarro = nVagasCarro;
		this.NVagasMoto = nVagasMoto;
		this.valorHoraCarro = valorHoraCarro;
		this.valorHoraMoto = valorHoraMoto;
	}

	// Atributos

	private int NVagasCarro, NVagasMoto;
	private double valorHoraCarro, valorHoraMoto;
	private double TotalArrecadadoDia;

	// Getters & Setters

	public int getNVagasCarro() {
		return NVagasCarro;
	}

	public void setNVagasCarro(int nVagasCarro) {
		NVagasCarro = nVagasCarro;
	}

	public int getNVagasMoto() {
		return NVagasMoto;
	}

	public void setNVagasMoto(int nVagasMoto) {
		NVagasMoto = nVagasMoto;
	}

	public double getValorHoraCarro() {
		return valorHoraCarro;
	}

	public void setValorHoraCarro(float valorHoraCarro) {
		this.valorHoraCarro = valorHoraCarro;
	}

	public double getValorHoraMoto() {
		return valorHoraMoto;
	}

	public void setValorHoraMoto(float valorHoraMoto) {
		this.valorHoraMoto = valorHoraMoto;
	}

	public double getTotalArrecadado() {
		return TotalArrecadadoDia;
	}

	public void setTotalArrecadado(double totalArrecadado) {
		TotalArrecadadoDia = totalArrecadado;
	}

	// Metodos

	public Boolean Estacionar(Carro c, double HoraEntrada) {
		if (this.getNVagasCarro() > 15) {
			System.out.println("Prezado(a), o estacionamento para estacionar o carro esta lotado!");
			return false;
		}
		if (HoraEntrada > 24) {
			System.out.println(
					"Prezado(a), o estacionamento esta fechado, a retirada do carro acontecera no proximo dia util!");
			return false;
		}
		double tempoEstacionado = c.getSaida() - c.getEntrada();
		double valorACobrar = tempoEstacionado * this.getValorHoraCarro();
		double valorCaixaAtual = this.getTotalArrecadado();
		double valorCaixaTotal = valorCaixaAtual + valorACobrar;
		this.setTotalArrecadado(valorCaixaTotal);
		this.setNVagasCarro(NVagasCarro - 1);
		System.out.println("O numero de vagas restantes para o carro é: " + NVagasCarro);
		return true;
	}

	public Boolean Estacionar(Moto m, double HoraEntrada) {
		if (this.getNVagasMoto() > 10) {
			System.out.println("Prezado(a), o estacionamento para estacionar a moto esta lotado!");
			return false;
		}
		if (HoraEntrada > 24) {
			System.out.println(
					"Prezado(a), o estacionamento esta fechado, a retirada da moto contecera no proximo dia util!");
			return false;
		}

		double tempoEstacionado = m.getSaida() - m.getEntrada();
		double valorACobrar = tempoEstacionado * this.getValorHoraMoto();
		double valorCaixaAtual = this.getTotalArrecadado();
		double valorCaixaTotal = valorCaixaAtual + valorACobrar;
		this.setTotalArrecadado(valorCaixaTotal);
		this.setNVagasMoto(NVagasMoto - 1);
		System.out.println("O numero de vagas restantes para a proxima moto é: " + NVagasMoto);
		return true;
	}

	public void RetirarCarro(Carro c, double HoraSaida) {

		c.setSaida(HoraSaida);

		if (HoraSaida > 24) {
			System.out.println(
					"Prezado(a), o estacionamento esta fechado, a retirada do carro acontecera no proximo dia util!");
		} else {
			double tempoEstacionado = c.getEntrada() - c.getSaida();
			double valorACobrar = tempoEstacionado * this.getValorHoraCarro();
			double valorCaixaAtual = this.getTotalArrecadado();
			double valorCaixaTotal = valorCaixaAtual + valorACobrar;
			this.setTotalArrecadado(valorCaixaTotal);
			int vagasRestantes = this.getNVagasCarro() + 1;
			System.out.println("O numero de vagas restantes no estacionamento para carros é: " + vagasRestantes);
		}
	}

	public void RetirarMoto(Moto m, double HoraSaida) {

		m.setSaida(HoraSaida);

		if (HoraSaida > 24) {
			System.out.println(
					"Prezado(a), o estacionamento esta fechado, a retirada da moto acontecera no proximo dia util!");
		} else {
			double tempoEstacionado = m.getEntrada() - m.getSaida();
			double valorACobrar = tempoEstacionado * this.getValorHoraCarro();
			double valorCaixaAtual = this.getTotalArrecadado();
			double valorCaixaTotal = valorCaixaAtual + valorACobrar;
			this.setTotalArrecadado(valorCaixaTotal);
			int vagasRestantes = this.getNVagasMoto() + 1;
			System.out.println("O numero de vagas restantes no estacionamento para motos é: " + vagasRestantes);
		}
	}

	public void SaldoCaixa() {
		System.out.println("O total que encontra-se no caixa é de: " + this.getTotalArrecadado());
	}
}
package Exercicio06;

public class Veiculo {

	// Constructor

	public Veiculo(String placa, String cor, double d) {
		this.cor = cor;
		this.placa = placa;
		this.entrada = d;
	}

	// Atributos

	private String placa, cor;
	private double entrada, saida;

	// Getters & Setters

	public String getPlaca() {
		return placa;
	}

	public void setPlaca(String placa) {
		this.placa = placa;
	}

	public String getCor() {
		return cor;
	}

	public void setCor(String cor) {
		this.cor = cor;
	}

	public double getEntrada() {
		return entrada;
	}

	public void setEntrada(double entrada) {
		this.entrada = entrada;
	}

	public double getSaida() {
		return saida;
	}

	public void setSaida(double saida) {
		this.saida = saida;
	}
}
package Exercicio07;

public class Teste {

	public static void main(String[] args) {

		// Instanciando novo objeto

		Gerente gerente = new Gerente();

		// Definindo valores

		gerente.setNome("Carlos Vieira");
		gerente.setSalario(3000);
		gerente.setUsuario("carlos.vieira");
		gerente.setSenha(5523);

		Funcionario funcionario = new Funcionario();
		funcionario.setNome("Pedro Castelo");
		funcionario.setSalario(1500);

		Telefonista telefonista = new Telefonista();
		telefonista.setNome("Luana Brana");
		telefonista.setSalario(1300.00);
		telefonista.setBaiadeTrabalho(20);
		telefonista.setTurno("Noite");
		telefonista.setJornada(200);

		Secretaria secretaria = new Secretaria();
		secretaria.setNome("Maria Ribeiro");
		secretaria.setSalario(1125.25);
		secretaria.setRamal(5);

		System.out.println("##### Gerente #####");
		System.out.println("Nome.: " + gerente.getNome());
		System.out.println("Salário.: " + gerente.getSalario());
		System.out.println("Usuário.: " + gerente.getUsuario());
		System.out.println("Senha.: " + gerente.getSenha());
		System.out.println("Bonificação.: " + gerente.calculaBonificacao());
		System.out.println();

		System.out.println("##### Funcionário #####");
		System.out.println("Nome.: " + funcionario.getNome());
		System.out.println("Salário.: " + funcionario.getSalario());
		System.out.println("Bonificação.: " + funcionario.calculaBonificacao());
		System.out.println();

		System.out.println("##### Telefonista #####");
		System.out.println("Nome.: " + telefonista.getNome());
		System.out.println("Salário.: " + telefonista.getSalario());
		System.out.println("Estação de Trabalho.: " + telefonista.getBaiadeTrabalho());
		System.out.println("Turno.: " + telefonista.getTurno());
		System.out.println("Jornada.: " + telefonista.getJornada());
		System.out.println("Bonificação.: " + telefonista.calculaBonificacao());
		System.out.println();

		System.out.println("##### Secretária #####");
		System.out.println("Nome.: " + secretaria.getNome());
		System.out.println("Salário.: " + secretaria.getSalario());
		System.out.println("Ramal.: " + secretaria.getRamal());
		System.out.println("Bonificação.: " + secretaria.calculaBonificacao());
		System.out.println();
	}
}
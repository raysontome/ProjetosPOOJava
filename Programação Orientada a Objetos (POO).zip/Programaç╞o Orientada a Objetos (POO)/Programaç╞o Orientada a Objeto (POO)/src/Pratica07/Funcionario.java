package Exercicio07;

public class Funcionario {

	// Atributos

	protected String Nome;
	protected int Salario;

	// Metodos

	public void calcBonificacao() {

		System.out.println("Imprime o valor de 5% em cima do salario");

	}
	// Getters & Setters

	public String getNome() {
		return Nome;
	}

	public void setNome(String nome) {
		Nome = nome;
	}

	public int getSalario() {
		return Salario;
	}

	public void setSalario(double d) {
		Salario = (int) d;
	}

	// Instanciar

	public double calculaBonificacao() {
		return this.Salario * 0.5;
	}
}
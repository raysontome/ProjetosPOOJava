package Exercicio07;

public class Gerente extends Funcionario {

	// Atributos

	private String Usuario;
	private int Senha;

	public void calcBonificacao() {
		System.out.println("Imprime o valor de 15% em cima do salario");

	}
	// Getters & Setters

	public String getUsuario() {
		return Usuario;
	}

	public void setUsuario(String usuario) {
		Usuario = usuario;
	}

	public int getSenha() {
		return Senha;
	}

	public void setSenha(int senha) {
		Senha = senha;
	}

	// Instanciar

	public double calculaBonificacao() {
		return this.getSalario() * 0.15 + 100;
	}
}
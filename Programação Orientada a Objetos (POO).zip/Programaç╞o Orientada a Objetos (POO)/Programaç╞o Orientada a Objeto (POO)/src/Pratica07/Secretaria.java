package Exercicio07;

public class Secretaria extends Funcionario {

	// Atributos

	private int Ramal;
	private String Email;

	// Metodos

	public void ligar(int i) {
		System.out.print("Ligando para o ramal" + i);
	}

	public void envEmail(String i) {
		System.out.print("Enviando email:" + i);
	}
	// Getters & Setters

	public int getRamal() {
		return Ramal;
	}

	public void setRamal(int ramal) {
		Ramal = ramal;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}
}
package Exercicio07;

public class Telefonista extends Funcionario {

	// Atributos

	private int BaiadeTrabalho;
	private float Jornada;
	private String Turno;

	// Getters & Setters

	public int getBaiadeTrabalho() {
		return BaiadeTrabalho;
	}

	public void setBaiadeTrabalho(int baiadeTrabalho) {
		BaiadeTrabalho = baiadeTrabalho;
	}

	public float getJornada() {
		return Jornada;
	}

	public void setJornada(float jornada) {
		Jornada = jornada;
	}

	public String getTurno() {
		return Turno;
	}

	public void setTurno(String turno) {
		Turno = turno;
	}
}
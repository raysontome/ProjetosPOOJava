package Exercicio13;

public class ControleRemoto implements Controlador {

	// Atributos

	private int volume;
	private int bateria;

	// Constructor

	public ControleRemoto() {
		this.setVolume(50);
		this.setBateria(100);
	}

	// Getters & Setters

	public int getVolume() {
		return this.volume;
	}

	public void setVolume(int v) {
		this.volume = v;
	}

	public int getBateria() {
		return this.bateria;
	}

	public void setBateria(int b) {
		this.bateria = b;
	}

	// Metodos

	@Override
	public void maisVolume() {
		this.setVolume(this.getVolume() + 5);
		System.out.println("\n (+ Volume): " + this.getVolume());
	}

	@Override
	public void menosVolume() {
		this.setVolume(this.getVolume() - 5);
		System.out.println("\n (-Volume): " + this.getVolume());
	}

	@Override
	public void cargaBateria() {
		System.out.println("\n (#Bateria): " + this.getBateria());
	}

	@Override
	public void dados() {
		System.out.println("\n (Infos. gerais Controle): ");
		System.out.println(" Volume: " + this.getVolume());
		System.out.println(" Bateria: " + this.getBateria());
	}

	@Override
	public void desligarTV() {
	}

	@Override
	public void aumentarCanal() {
	}

	@Override
	public void diminuirCanal() {
	}

	@Override
	public void pesquisarCanal() {
	}
}
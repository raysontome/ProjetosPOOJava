package Exercicio13;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class RotinaPrincipal {

	public static void main(String[] args) {

		// Coletar hora conforme esta configurado no sistema

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy hh:mm");
		System.out.println("Ola, hoje sao: " + sdf.format(new Date()));
		System.out.printf("__________________________");

		// Utilizando o Scanner para o usuario digitar a opcao 5.

		int nOpc = -1;
		Scanner ler = new Scanner(System.in);

		// Criando o Objeto TV e CR

		Televisao TV = new Televisao();

		ControleRemoto CR = new ControleRemoto();

		System.out.printf("\n > Menu do Controle Remoto:");
		CR.maisVolume();
		CR.menosVolume();
		CR.cargaBateria();
		TV.aumentarCanal();
		TV.diminuirCanal();
		TV.dados();
		CR.dados();
		TV.desligarTV();
		System.out.printf("\n 5- * Pesquisar canal: Insira o Canal: ");
		TV.setCanal(ler.nextInt());
	}
}
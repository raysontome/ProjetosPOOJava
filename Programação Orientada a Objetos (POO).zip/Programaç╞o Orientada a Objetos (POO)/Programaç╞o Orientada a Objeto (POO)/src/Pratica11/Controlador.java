package Exercicio13;

public interface Controlador {

	// Classe Controle

	public abstract void maisVolume();

	public abstract void menosVolume();

	public abstract void cargaBateria();

	public abstract void desligarTV();

	public abstract void aumentarCanal();

	public abstract void diminuirCanal();

	public abstract void pesquisarCanal();

	public abstract void dados();
}
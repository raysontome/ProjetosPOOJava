package Exercicio13;

public class Televisao implements Controlador {

	// Atributos

	private int Canal;

	// Constructor

	public Televisao() {
		this.setCanal(2);
	}

	// Getters & Setters

	public int getCanal() {
		return this.Canal;
	}

	public void setCanal(int nCa) {
		this.Canal = nCa;
	}

	// Metodos

	@Override
	public void aumentarCanal() {
		this.setCanal(this.getCanal() + 2);
		System.out.println("\n (+ Canal): " + this.getCanal());
	}

	@Override
	public void diminuirCanal() {
		this.setCanal(this.getCanal() - 2);
		System.out.println("\n (- Canal): " + this.getCanal());
	}

	@Override
	public void pesquisarCanal() {
	}

	@Override
	public void dados() {
		System.out.println("\n (Infos. gerais TV): ");
		System.out.println(" Canal: " + this.getCanal());
	}

	@Override
	public void desligarTV() {
		System.out.printf("\n OFF TV! See you soon. /o/ \n");
	}

	@Override
	public void maisVolume() {
	}

	@Override
	public void menosVolume() {
	}

	@Override
	public void cargaBateria() {
	}
}
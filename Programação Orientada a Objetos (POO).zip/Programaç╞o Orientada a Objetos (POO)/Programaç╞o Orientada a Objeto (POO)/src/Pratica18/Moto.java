package Exercicio23;

public class Moto extends Veiculo {

}
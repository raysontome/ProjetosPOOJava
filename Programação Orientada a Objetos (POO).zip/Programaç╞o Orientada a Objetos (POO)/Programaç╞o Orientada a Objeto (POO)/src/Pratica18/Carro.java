package Exercicio23;

public class Carro extends Veiculo {

}
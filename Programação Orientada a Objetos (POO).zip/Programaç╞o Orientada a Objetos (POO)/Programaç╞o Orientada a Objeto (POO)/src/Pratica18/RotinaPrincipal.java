package Exercicio23;

public class RotinaPrincipal {

	public static void main(String[] args) {

	}

}
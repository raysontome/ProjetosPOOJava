package Exercicio23;

import Exercicio06.Carro;

public class Estacionamento extends Empresa {

	private static final double valorCaixaTotal = 0;

	// Constructor
	public Estacionamento(int nVagasCarro, int nVagasMoto, double valorHoraCarro, double valorHoraMoto) {
		this.NVagasCarro = nVagasCarro;
		this.NVagasMoto = nVagasMoto;
		this.valorHoraCarro = valorHoraCarro;
		this.valorHoraMoto = valorHoraMoto;
	}

	// Atributos
	private int NVagasCarro, NVagasMoto, NCarros, NMotos;
	private double valorHoraCarro, valorHoraMoto;
	private double TotalArrecadadoDia, TotalCaixa;

	// Encapsulamento
	public int getNVagasCarro() {
		return NVagasCarro;
	}

	public void setNVagasCarro(int nVagasCarro) {
		NVagasCarro = nVagasCarro;
	}

	public int getNVagasMoto() {
		return NVagasMoto;
	}

	public void setNVagasMoto(int nVagasMoto) {
		NVagasMoto = nVagasMoto;
	}

	public int getNCarros() {
		return NCarros;
	}

	public void setNCarros(int nCarros) {
		NCarros = nCarros;
	}

	public int getNMotos() {
		return NMotos;
	}

	public void setNMotos(int nMotos) {
		NMotos = nMotos;
	}

	public double getValorHoraCarro() {
		return valorHoraCarro;
	}

	public void setValorHoraCarro(double valorHoraCarro) {
		this.valorHoraCarro = valorHoraCarro;
	}

	public double getValorHoraMoto() {
		return valorHoraMoto;
	}

	public void setValorHoraMoto(double valorHoraMoto) {
		this.valorHoraMoto = valorHoraMoto;
	}

	public double getTotalArrecadadoDia() {
		return TotalArrecadadoDia;
	}

	public void setTotalArrecadadoDia(double totalArrecadadoDia) {
		TotalArrecadadoDia = totalArrecadadoDia;
	}

	public double getTotalCaixa() {
		return TotalCaixa;
	}

	public void setTotalCaixa(double totalCaixa) {
		TotalCaixa = totalCaixa;
	}

	// Metodos
	public Boolean EstacionarCarro(Carro a, Carro b) {
		if (this.getNVagasCarro() > 15) {
			System.out.println("Prezado(a), o estacionamento para estacionar o carro esta lotado!");
			return false;
		}
		double valorCaixaAtual = this.getTotalArrecadadoDia();
		this.setTotalArrecadadoDia(valorCaixaTotal);
		this.setNVagasCarro(NVagasCarro - 1);
		System.out.println("O numero de vagas restantes para o carro é: " + NVagasCarro);
		return true;
	}

	public Boolean EstacionarMoto(Moto c, Moto d) {
		if (this.getNVagasCarro() > 15) {
			System.out.println("Prezado(a), o estacionamento para estacionar o carro esta lotado!");
			return false;
		}
		double valorCaixaAtual = this.getTotalArrecadadoDia();
		this.setTotalArrecadadoDia(valorCaixaTotal);
		this.setNVagasCarro(NVagasCarro - 1);
		System.out.println("O numero de vagas restantes para o carro é: " + NVagasCarro);
		return true;
	}

	public void Retirar(Carro a, Carro b, Moto c, Moto d, double HoraSaida ) {

		if (HoraSaida > 24) {
			System.out.println(
					"Prezado(a), o estacionamento esta fechado, a retirada da moto acontecera no proximo dia util!");
		} else {
			double valorCaixaAtual = this.getTotalArrecadadoDia();
			this.setTotalArrecadadoDia(valorCaixaTotal);
			int vagasRestantes = this.getNVagasMoto() + 1;
			System.out.println("O numero de vagas restantes no estacionamento para motos é: " + vagasRestantes);
		}
	}

	public void FecharCaixa() {

		System.out.println("O total que encontra-se no caixa é de: " + this.getTotalArrecadadoDia());
	}
}
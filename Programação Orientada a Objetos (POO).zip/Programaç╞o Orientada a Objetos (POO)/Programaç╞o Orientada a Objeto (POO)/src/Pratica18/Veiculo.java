package Exercicio23;

public abstract class Veiculo {

	// Atributos
	private String placa;
	private double horaEntrada;

	// Metodos
	private void buzinar() {
		System.out.println("O veiculo esta buzinando!");
	}
}
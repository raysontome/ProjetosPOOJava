package Exercicio23;

public interface PessoaJuridica {

	// Metodos
	private void gerarCNPJ() {
	}

	private void emitirNota(float Valor) {
	}
}
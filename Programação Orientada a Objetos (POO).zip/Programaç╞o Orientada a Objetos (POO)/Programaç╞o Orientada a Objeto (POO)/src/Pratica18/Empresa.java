package Exercicio23;

public abstract class Empresa {

	// Atributos
	private String setor, nomeFantasia, Endereco;
	private int HRFuncionamento;

	// Encapsulamento
	public String getSetor() {
		return setor;
	}

	public void setSetor(String setor) {
		this.setor = setor;
	}

	public String getNomeFantasia() {
		return nomeFantasia;
	}

	public void setNomeFantasia(String nomeFantasia) {
		this.nomeFantasia = nomeFantasia;
	}

	public String getEndereco() {
		return Endereco;
	}

	public void setEndereco(String endereco) {
		Endereco = endereco;
	}

	public int getHRFuncionamento() {
		return HRFuncionamento;
	}

	public void setHRFuncionamento(int hRFuncionamento) {
		HRFuncionamento = hRFuncionamento;
	}
}
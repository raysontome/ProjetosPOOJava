package Exercicio23;

public interface Website {

	// Metodos
	private void registrarDominio() {

	}
}
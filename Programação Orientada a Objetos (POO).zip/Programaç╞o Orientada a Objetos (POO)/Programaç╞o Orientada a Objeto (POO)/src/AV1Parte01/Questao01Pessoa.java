package AV1Parte01;

public class Questao01Pessoa {

	// Constructor

	public Questao01Pessoa(String nome, int nascimento, float altura) {
		this.setNome(nome);
		this.setAltura(altura);
		this.setNascimento(nascimento);
		this.setIdade(0);
	}

	// Atributos

	private String nome;
	private int idade;
	private int nascimento;
	private float altura;

	// Getters & Setters

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		this.idade = idade;
	}

	public int getNascimento() {
		return nascimento;
	}

	public void setNascimento(int nascimento) {
		this.nascimento = nascimento;
	}

	public float getAltura() {
		return altura;
	}

	public void setAltura(float altura) {
		this.altura = altura;
	}

	// Metodos

	public void imprimir() {
		System.out.println(this.getNome());
		System.out.println("");
		System.out.println(this.getNascimento());
		System.out.println("");
		System.out.println(this.getAltura());
		System.out.println("");
		if (this.getIdade() != 0) {
			System.out.println(this.getIdade());
		}
	}

	public void calculoIdade() {
		this.setIdade(2018 - this.getNascimento());
	}
}
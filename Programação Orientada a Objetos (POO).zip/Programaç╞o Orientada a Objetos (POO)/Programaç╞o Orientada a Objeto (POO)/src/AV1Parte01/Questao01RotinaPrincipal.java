package AV1Parte01;

public class Questao01RotinaPrincipal {

	public static void main(String[] args) {

		// Instanciando novo objeto

		Questao01Pessoa Pessoa01 = new Questao01Pessoa("Rayson Tome", 1995, 1.72f);

		// Rotina Principal

		Pessoa01.imprimir();

		Pessoa01.calculoIdade();

		Pessoa01.imprimir();
	}
}
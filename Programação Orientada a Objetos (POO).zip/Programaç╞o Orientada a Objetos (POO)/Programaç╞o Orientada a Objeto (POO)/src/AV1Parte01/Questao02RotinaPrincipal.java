package AV1Parte01;

public class Questao02RotinaPrincipal {

	public static void main(String[] args) {

		// Instanciando novo objeto

		Questao02Elevador NovoElevador01 = new Questao02Elevador();

		// Rotina Principal

		System.out.println("#Bem vindo ao Elevador!#");
		NovoElevador01.entrar(2);
		NovoElevador01.subir(2);
		NovoElevador01.subir(11);
		NovoElevador01.subir(6);
		NovoElevador01.subir(10);
		NovoElevador01.entrar(5);
	}
}
package AV1Parte01;

public class Questao02Elevador {

	// Atributos

	private int andarAtual, totalAndares, capacidadedoElevador, QTDPassageiroAtual;

	// Constructor

	public Questao02Elevador() {
		this.setCapacidadeElevador(0);
		this.setQuantidadePessoasAtual(0);
		this.setAndarAtual(0);
		this.setTotalAndares(0);
	}

	// Getters & Setters

	public int getAndarAtual() {
		return andarAtual;
	}

	public void setAndarAtual(int andarAtual) {
		this.andarAtual = andarAtual;
	}

	public int getTotalAndares() {
		return totalAndares;
	}

	public void setTotalAndares(int totalAndares) {
		this.totalAndares = totalAndares;
	}

	public int getCapacidadeElevador() {
		return capacidadedoElevador;
	}

	public void setCapacidadeElevador(int capacidadeElevador) {
		this.capacidadedoElevador = capacidadeElevador;
	}

	public int getQuantidadePessoasAtual() {
		return QTDPassageiroAtual;
	}

	public void setQuantidadePessoasAtual(int quantidadeAtual) {
		this.QTDPassageiroAtual = quantidadeAtual;
	}

	// Metodos

	public void entrar(int enter) {
		if (this.getQuantidadePessoasAtual() + enter > 10) {
			System.out.println("Prezado, o Elevador suporta apenas 10 passageiros!");
		} else if (this.getQuantidadePessoasAtual() + enter >= 7) {
			this.setQuantidadePessoasAtual(this.getQuantidadePessoasAtual() - enter);
		}
	}

	public void sair(int out) {
		if (this.getQuantidadePessoasAtual() == 0) {
			System.out.println("Prezado, o Elevador esta vazio!");
		} else if (this.getQuantidadePessoasAtual() > out) {
			this.setQuantidadePessoasAtual(this.getQuantidadePessoasAtual() - out);
		} else if (this.getQuantidadePessoasAtual() == out) {
			System.out.println("Os passageiros sairam do Elevador!");
			this.setQuantidadePessoasAtual(this.getQuantidadePessoasAtual() - out);
		} else {
			System.out.println("Prezado, nao sera possivel retirar os " + out + " passageiros, so ha apenas "
					+ this.getQuantidadePessoasAtual() + " pessoas dentro!");
		}
	}

	public void subir(int up) {
		if (this.getAndarAtual() == 10) {
			System.out.println("Voce ja esta no ultimo andar!");
		} else if (this.getAndarAtual() + up > 10) {
			System.out.println(
					"Nao pode subir " + up + " andares, atualmente esta no " + this.getAndarAtual() + " andar!");
		} else if (this.getAndarAtual() + up <= 10) {
			this.setAndarAtual(this.getAndarAtual() + up);
			System.out.println(this.getAndarAtual() + " andar");
		}
	}

	public void descer(int above) {
		if (this.getAndarAtual() == 0) {
			System.out.println("Nao pode descer, esta no terreo!");
		} else if (this.getAndarAtual() - above < 0) {
			System.out.println(
					"Nao pode descer " + above + " andares, atualmente no " + this.getAndarAtual() + " andar!");
		} else if (this.getAndarAtual() - above >= 0) {
			this.setAndarAtual(this.getAndarAtual() - above);
			System.out.println(this.getAndarAtual() + " andar");
		}
	}
}
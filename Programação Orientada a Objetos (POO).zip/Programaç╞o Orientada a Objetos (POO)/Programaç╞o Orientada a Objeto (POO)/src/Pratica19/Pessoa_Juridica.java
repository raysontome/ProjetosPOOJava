package Exercicio24;

interface Pessoa_Juridica {
    void gerarCNPJ(String CNPJ);
    void emitirNota(double valor);

}
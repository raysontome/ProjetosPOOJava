package Exercicio24;

public class Lancha extends Veiculo {

	    public Lancha(String placa, int horaEntrada) {
	        super(placa);
	    }
	}
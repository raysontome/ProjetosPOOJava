package Exercicio24;

public class Jetski extends Veiculo {
    public Jetski(String placa, int horaEntrada) {
        super(placa);
    }
}
package Exercicio24;

	class Estacionamento extends Empresa implements Pessoa_Juridica, Website {
	    private int vagasCarro;
	    private int vagasMoto;
	    private int numCarros;
	    private int numMotos;
	    private double valorHoraCarro;
	    private double valorHoraMoto;
	    private double totalArrecadadoDoDia;
	    private double totalCaixa;
	    private String CNPJ;



	    //Constructor
	    public Estacionamento(String setor, String nomeFantasia, String endereco, String funcionamento, int vagasCarro, int vagasMoto, int numCarros,
	                          int numMotos, double valorHoraCarro, double valorHoraMoto, double totalArrecadadoDoDia, double totalCaixa) {
	        super(setor, nomeFantasia, endereco, funcionamento);
	        setVagasCarro (vagasCarro);
	        setVagasMoto (vagasMoto);
	        setNumCarros (numCarros);
	        setNumMotos (numMotos);
	        setValorHoraCarro (valorHoraCarro);
	        setValorHoraMoto (valorHoraMoto);
	        setTotalArrecadadoDoDia (totalArrecadadoDoDia);
	        setTotalCaixa (totalCaixa);
	    }

	    // Getters & Setters
	    public int getVagasCarro() {return vagasCarro;}

	    public void setVagasCarro(int vagasCarro) {this.vagasCarro = vagasCarro;}

	    public int getVagasMoto() {return vagasMoto;}

	    public void setVagasMoto(int vagasMoto) {this.vagasMoto = vagasMoto;}

	    public int getNumCarros() {return numCarros;}

	    public void setNumCarros(int numCarros) {this.numCarros = numCarros;}

	    public int getNumMotos() {return numMotos;}

	    public void setNumMotos(int numMotos) {this.numMotos = numMotos;}

	    public double getValorHoraCarro() {return valorHoraCarro;}

	    public void setValorHoraCarro(double valorHoraCarro) {this.valorHoraCarro = valorHoraCarro;}

	    public double getValorHoraMoto() {return valorHoraMoto;}

	    public void setValorHoraMoto(double valorHoraMoto) {this.valorHoraMoto = valorHoraMoto;}

	    public double getTotalArrecadadoDoDia() {return totalArrecadadoDoDia;}

	    public void setTotalArrecadadoDoDia(double totalArrecadadoDoDia) {this.totalArrecadadoDoDia = totalArrecadadoDoDia;}

	    public double getTotalCaixa() {return totalCaixa;}

	    public void setTotalCaixa(double totalCaixa) {this.totalCaixa = totalCaixa;}

	    public String getCNPJ() {return CNPJ;}

	    public void setCNPJ(String CNPJ) {this.CNPJ = CNPJ;}

	    //Métodos
	    void estacionarCarro(Lancha l, int horaEntrada){
	        if (getNumCarros() >= getVagasCarro()){
	            System.out.println("Impossível estacionar. Todas as vagas estão ocupadas.");
	        }else {
	            setNumCarros(getNumCarros() + 1);
	            l.setHoraEntrada(horaEntrada);
	        }
	    }
	    void estacionarCarro(Lancha l1, int horaEntrada1, Lancha l2, int horaEntrada2){
	        if (getNumCarros() >= getVagasCarro()){
	            System.out.println("Impossível estacionar. Todas as vagas estão ocupadas.");
	        }else {
	            setNumCarros(getNumCarros() + 1);
	            l1.setHoraEntrada(horaEntrada1);
	            setNumCarros(getNumCarros() + 1);
	            l2.setHoraEntrada(horaEntrada2);
	        }
	    }
	    void estacionarMoto(Jetski j, int horaEntrada){
	        if (getNumMotos() >= getVagasMoto()){
	            System.out.println("Impossível estacionar. Todas as vagas estão ocupadas.");
	        }else {
	            setNumMotos(getNumMotos() + 1);
	            j.setHoraEntrada(horaEntrada);
	        }
	    }
	    void estacionarMoto(Jetski j1, int horaEntrada1, Jetski j2, int horaEntrada2){
	        if (getNumMotos() >= getVagasMoto()){
	            System.out.println("Impossível estacionar. Todas as vagas estão ocupadas.");
	        }else {
	            setNumMotos(getNumMotos() + 1);
	            j1.setHoraEntrada(horaEntrada1);
	            setNumMotos(getNumMotos() + 1);
	            j2.setHoraEntrada(horaEntrada2);
	        }
	    }

	    void Retirar(Lancha l, int horaSaida) {
	        if (getNumCarros() <= 0){
	            System.out.println("Impossível estacionar. Todas as vagas estão ocupadas.");
	        }else {
	            double valor = getValorHoraCarro() * (horaSaida - l.getHoraEntrada());
	            emitirNota(valor);
	            setTotalArrecadadoDoDia(getTotalArrecadadoDoDia() + valor);
	            setNumCarros(getNumCarros()-1);
	        }
	    }

	    void Retirar(Jetski j, int horaSaida){
	        if (getNumCarros() <=0){
	            System.out.println("Impossível estacionar. Todas as vagas estão ocupadas.");
	        }else {
	            double valor = getValorHoraCarro() * (horaSaida - j.getHoraEntrada());
	            emitirNota(valor);
	            setTotalArrecadadoDoDia(getTotalArrecadadoDoDia() + valor);
	            setNumMotos(getNumMotos()-1);
	        }

	    }
	    void fecharCaixa(){
	        setTotalCaixa(getTotalCaixa() + getTotalArrecadadoDoDia());
	        setTotalArrecadadoDoDia(0);
	        System.out.println("O total arrecadado no dia de hoje foi de R$: " + getTotalArrecadadoDoDia() + ". O total do caixa é de R$: "
	        + getTotalCaixa() +".");

	    }


	    public void gerarCNPJ(String CNPJ) {
	        System.out.println("O CNPJ do Estacionamento é:" + CNPJ + ".");
	        setCNPJ(CNPJ);
	    }


	    public void emitirNota(double valor) {System.out.println("O valor da nota é R$: " + valor + ", no estacionamento de CNPJ: " + getCNPJ() +".");}


	    public void registrarWebsite(String url) {System.out.println("Domínio registrado na URL: " +url +".");}
	}
package Exercicio24;

abstract class Veiculo {
    protected String placa;
    protected int horaEntrada;

    public Veiculo(String placa) {
        setPlaca (placa);
        setHoraEntrada (horaEntrada);
    }

    public String getPlaca() {return placa;}

    public void setPlaca(String placa) {this.placa = placa;}

    public int getHoraEntrada() {return horaEntrada;}

    public void setHoraEntrada(int horaEntrada) {this.horaEntrada = horaEntrada;}

    void Buzinar(){System.out.println("FON");}
}
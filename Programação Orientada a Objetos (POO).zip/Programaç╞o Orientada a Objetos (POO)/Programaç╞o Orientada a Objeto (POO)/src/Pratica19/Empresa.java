package Exercicio24;

	abstract class Empresa {
	    protected String setor;
	    protected String nomeFantasia;
	    protected String endereco;
	    protected String funcionamento;

	    public Empresa(String setor, String nomeFantasia, String endereco, String funcionamento) {
	        setSetor (setor);
	        setNomeFantasia (nomeFantasia);
	        setEndereco(endereco);
	        setFuncionamento (funcionamento);
	    }

	    public String getSetor() {return setor;}

	    public void setSetor(String setor) {this.setor = setor;}

	    public String getNomeFantasia() {return nomeFantasia;}

	    public void setNomeFantasia(String nomeFantasia) {this.nomeFantasia = nomeFantasia;}

	    public String getEndereco() {return endereco;}

	    public void setEndereco(String endereco) {this.endereco = endereco;}

	    public String getFuncionamento() {return funcionamento;}

	    public void setFuncionamento(String funcionamento) {this.funcionamento = funcionamento;}
	}
package Exercicio24;

interface Website {
    void registrarWebsite(String url);
}
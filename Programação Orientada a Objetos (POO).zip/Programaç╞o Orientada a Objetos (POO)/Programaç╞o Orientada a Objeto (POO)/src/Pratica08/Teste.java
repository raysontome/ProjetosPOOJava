package Exercicio08;

class Teste {

	public static void main(String[] args) {

		// Instanciando um novo objeto e definindo valores
		Cliente c1 = new Cliente(60397757, "96766936", "Avenida Cesar", "raysontome@icloud.com");

		// Cliente
		System.out.println("#Dados do Clienter#");
		System.out.println("___________________");
		c1.impCadastro();

		// ClienteNet
		// ClienteNET cn = new ClienteNET("Ismael", 1996, 064440, "Rua Joaquim", 45678,
		// "ismael.duarte", 05, 10, 18, status);
	}
}
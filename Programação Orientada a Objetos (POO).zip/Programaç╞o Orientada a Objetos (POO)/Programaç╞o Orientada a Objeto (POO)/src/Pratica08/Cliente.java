package Exercicio08;

public class Cliente {

	// Constructor
	protected Cliente(int CPF, String telefone, String endereco, String email) {
		super();
		CPF = CPF;
		Telefone = telefone;
		Endereco = endereco;
		Email = email;
	}

	// Atributos

	int CPF;
	String Telefone, Endereco, Email;

	// Metodos

	public void impCadastro() {
		System.out.println("Qual seu CPF? " + getCPF());
		System.out.println("Qual seu endereco? " + getEndereco());
		System.out.println("Qual seu telefone? " + getTelefone());
		System.out.println("Qual seu email? " + getEmail());
	}

	// Getters & Setters

	public int getCPF() {
		return CPF;
	}

	public void setCPF(int CPF) {
		CPF = CPF;
	}

	public String getTelefone() {
		return Telefone;
	}

	public void setTelefone(String telefone) {
		Telefone = telefone;
	}

	public String getEndereco() {
		return Endereco;
	}

	public void setEndereco(String endereco) {
		Endereco = endereco;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}
}
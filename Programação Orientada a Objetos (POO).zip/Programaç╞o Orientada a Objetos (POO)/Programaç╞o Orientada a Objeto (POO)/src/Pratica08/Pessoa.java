package Exercicio08;

public class Pessoa extends Cliente {

	// Constructor
	public Pessoa(int CPF, String telefone, String endereco, String email) {
		super(CPF, telefone, endereco, email);
	}

	// Atributos
	String Nome;
	float DataNasc;

	// Metodos
	public void idade() {
		System.out.println("Qual sua idade" + getDataNasc());
	}

	// Getters & Setters
	public String getNome() {
		return Nome;
	}

	public void setNome(String nome) {
		Nome = nome;
	}

	public float getDataNasc() {
		return DataNasc;
	}

	public void setDataNasc(float dataNasc) {
		DataNasc = dataNasc;
	}
}
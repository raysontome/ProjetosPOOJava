package Exercicio08;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Set;

public class ClienteNET extends Cliente {

	// Constructor

	public ClienteNET(int CPF, String telefone, String endereco, String email, int vencimentoDia, int vencimentoMes,
			boolean devedor, int juros, String pacote) {
		super(CPF, telefone, endereco, email);
		this.vencimentoDia = vencimentoDia;
		this.vencimentoMes = vencimentoMes;
		Devedor = devedor;
		Juros = juros;
		Pacote = pacote;
	}

	// Atributos

	public int vencimentoDia, vencimentoMes;
	private boolean Devedor;
	private int Juros;
	public String Pacote;

	// Metodos

	public void impCadastro() {
		System.out.println("Informe seu CPF:" + this.getCPF());
		System.out.println("Informe seu Telefone: " + this.getTelefone());
		System.out.println("Informe seu Endereco: " + this.getEndereco());
		System.out.println("Informe seu Email: " + this.getEmail());
		System.out.println("Informe seu Vencimento (dia): " + this.getVencimentoDia());
		System.out.println("Informe seu Vencimento (mes): " + this.getVencimentoMes());
		System.out.println("Saldo devedor: " + this.getDevedor());
		System.out.println("Juros: " + this.getJuros());
		System.out.println("Tipo de pacote: " + this.getPacote());
	}

	public int pgrMensalidade() {
		if (Devedor == false) {
			System.out.println("Nao estou devendo!");

		} else {
			System.out.println("Estou devendo!" + Juros);
		}
		return 0;
	}

	public void status(int data) {
		int dia;
		if (this.getVencimentoDia() > data) {
			System.out.println("Cliente devendo juros!");
		}
	}

	// public String getDateTime() {
	DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
	Date date = new Date();
	// System.out.println("Hora: " + date);

	// Getters & Setters

	public int getVencimentoDia() {
		return vencimentoDia;
	}

	public void setVencimentoDia(int vencimentoDia) {
		this.vencimentoDia = vencimentoDia;
	}

	public int getVencimentoMes() {
		return vencimentoMes;
	}

	public void setVencimentoMes(int vencimentoMes) {
		this.vencimentoMes = vencimentoMes;
	}

	public boolean getDevedor() {
		return Devedor;
	}

	public void setDevedor(boolean devedor) {
		Devedor = devedor;
	}

	public int getJuros() {
		return Juros;
	}

	public void setJuros(int juros) {
		Juros = juros;
	}

	public String getPacote() {
		return Pacote;
	}

	public void setPacote(String pacote) {
		Pacote = pacote;
	}
}
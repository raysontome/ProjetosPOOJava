package Exercicio05;

public class RotinaPrincipal {

	public static void main(String[] args) {

		// Instanciando o novo objeto

		ControleRemoto c = new ControleRemoto();

		// Rotina Principal

		c.abrirMenu();
		c.ligar();
		c.play();
		c.maisVolume();
		c.abrirMenu();
		c.ligar();
		c.play();
		c.maisVolume();
		c.maisVolume();
		c.play();
	}
}
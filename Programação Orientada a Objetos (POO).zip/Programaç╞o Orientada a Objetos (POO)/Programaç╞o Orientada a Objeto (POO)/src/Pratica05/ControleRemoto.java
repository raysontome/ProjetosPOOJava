package Exercicio05;

public class ControleRemoto implements ControladorPadrao {

	// Atributos

	private int volume, bateria;
	private boolean ligado, tocando;

	// Constructor

	public ControleRemoto() {
		this.setVolume(50);
		this.setLigado(false);
		this.setTocando(false);
		this.setBateria(100);
	}

	// Getters & Setters
	private void setVolume(int v) {
		this.volume = v;
	}

	private int getVolume() {
		return volume;
	}

	private void setLigado(boolean l) {
		this.ligado = l;
	}

	private boolean getLigado() {
		return ligado;
	}

	private void setTocando(boolean t) {
		this.tocando = t;
	}

	private boolean getTocando() {
		return tocando;
	}

	public int getBateria() {
		return bateria;
	}

	public void setBateria(int b) {
		this.bateria = b;
	}

	// Metodos

	@Override
	public void ligar() {
		this.setLigado(true);
	}

	@Override
	public void desligar() {
		this.setLigado(false);
	}

	@Override
	public void abrirMenu() {
		System.out.println("----# Bem vindo! #----");
		System.out.println("----Menu:----");
		System.out.println("A televisao esta ligada? Status: " + this.getLigado());
		System.out.println("A televisao esta tocando? Status: " + this.getTocando());
		System.out.print("Volume: " + this.getVolume());
		for (int i = 1; i <= this.getVolume(); i += 10) {
			System.out.print(" [-]");
		}
		System.out.println("");
	}

	@Override
	public void fecharMenu() {
		System.out.println("Fechando volume.");
		System.out.println("--------------------");
	}

	@Override
	public void maisVolume() {
		if (this.getLigado()) {
			this.setVolume(this.getVolume() + 5);
		} else {
			System.out.println("Prezado, ligue o Controle Remoto!");
			System.out.println("--------------------");
		}
	}

	@Override
	public void menosVolume() {
		if (this.getLigado()) {
			this.setVolume(this.getVolume() - 5);
		} else {
			System.out.println("Prezado, ligue o Controle Remoto!");
			System.out.println("--------------------");
		}
	}

	@Override
	public void ligarMudo() {
		if (this.getVolume() > 0 && this.getLigado()) {
			this.setVolume(0);
			System.out.println("A funcao mudo esta ligado.");
		} else if (this.getVolume() == 0 && this.getLigado()) {
			System.out.println("A funcao mudo já encontra-se ativo.");
			System.out.println("--------------------");
		} else {
			System.out.println("Prezado, ligue o Controle Remoto!");
			System.out.println("--------------------");
		}
	}

	@Override
	public void desligarMudo() {
		if (this.getVolume() == 0 && this.getLigado()) {
			this.setVolume(50);
			System.out.println("A funcao mudo esta desligado.");
		} else if (this.getVolume() > 0 && this.getLigado()) {
			System.out.println("A funcao mudo já encontra-se desligado.");
			System.out.println("--------------------");
		} else {
			System.out.println("Prezado, ligue o Controle Remoto!");
			System.out.println("--------------------");
		}
	}

	@Override
	public void play() {
		if (this.getLigado() && !(this.getTocando())) {
			this.setTocando(true);
			System.out.println("Play ativo.");
			System.out.println("--------------------");
		} else if (!(this.getLigado()) && !(this.getTocando())) {
			System.out.println("Prezado, ligue a televisão!");
			System.out.println("--------------------");
		} else {
			System.out.println("Já está tocando...");
			System.out.println("--------------------");
		}
	}

	@Override
	public void pause() {
		if (this.getLigado() && this.getTocando()) {
			this.setTocando(false);
			System.out.println("Pause ativo.");
			System.out.println("--------------------");
		} else if (!(this.getLigado()) && !(this.getTocando())) {
			System.out.println("Prezado, ligue a televisão!");
			System.out.println("--------------------");
		} else {
			System.out.println("Já está no pause");
			System.out.println("--------------------");
		}
	}
}
package Exercicio14;

public class Papagaio extends Ave {

	// Atributos
	
	private String nome;

	// Metodos

	public void emitirSom() {
		System.out.println("O Papagaio esta emitindo um som");
	}

	public void voar() {
		System.out.println("O Papagaio esta voando");
	}

	// Getters & Setters

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
}
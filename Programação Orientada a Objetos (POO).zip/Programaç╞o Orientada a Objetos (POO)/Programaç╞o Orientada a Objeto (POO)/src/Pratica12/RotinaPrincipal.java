package Exercicio14;

public class RotinaPrincipal {

	public static void main(String[] args) {

		// Mamiferos

		Cachorro c = new Cachorro();
		Cavalo k = new Cavalo();
		Gato g = new Gato();

		// Cachorro
		c.idade(10);
		c.amamentar();
		c.emitirSom();
		c.alimentar();
		c.locomover();
		c.setMembros(4);
		c.setPeso(30);
		c.setCorPelo("Preto");
		c.setNome("Pantera");

		System.out.println("--------------------------------");

		// Cavalo
		k.idade(15);
		k.amamentar();
		k.emitirSom();
		k.alimentar();
		k.locomover();
		k.setMembros(4);
		k.setPeso(40);
		k.setCorPelo("Branco");
		k.setNome("Joao");

		System.out.println("--------------------------------");

		// Gato
		g.idade(7);
		g.amamentar();
		g.emitirSom();
		g.alimentar();
		g.locomover();
		g.setMembros(4);
		g.setPeso(20);
		g.setCorPelo("Preto");
		g.setNome("Pri");

		System.out.println("--------------------------------");

		// Ave

		Papagaio p = new Papagaio();

		// Papagaio
		p.idade(3);
		p.emitirSom();
		p.voar();
		p.alimentar();
		p.fazerNinho();
		p.setMembros(2);
		p.setPeso(5);
		p.setCorPena("Branca");
		p.setNome("Maria");
		p.locomover();

		System.out.println("--------------------------------");

		// Reptil

		Peixe pe = new Peixe();

		// Peixe
		pe.idade(3);
		pe.emitirSom();
		pe.alimentar();
		pe.locomover();
		pe.soltarBolha();
		pe.setMembros(0);
		pe.setPeso(2);
		pe.setNome("Peixe dourado");
	}
}
package Exercicio14;

public class Mamifero extends Animal {

	// Atributos

	private String corPelo;

	// Metodos

	@Override
	public void locomover() {
		System.out.println("O mamifero esta correndo");
	}

	@Override
	public void alimentar() {
		System.out.println("O mamifero esta alimentando");
	}

	@Override
	public void emitirSom() {
		System.out.println("O mamifero esta emitindo um som");
	}

	// Getters & Setters

	public String getCorPelo() {
		return corPelo;
	}

	public void setCorPelo(String corPelo) {
		this.corPelo = corPelo;
	}
}
package Exercicio14;

public class Cachorro extends Mamifero {

	// Atributos

	private String nome;

	// Metodos

	public void emitirSom() {
		System.out.println("O Cachorro esta emitindo um som");
	}

	public void amamentar() {
		System.out.println("O Cachorro esta amamentando");
	}

	// Getters & Setters

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;	
	}
}
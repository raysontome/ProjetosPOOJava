package Exercicio14;

public class Peixe extends Animal {

	// Atributos

	private String Nome;

	// Metodos

	@Override
	public void locomover() {
		System.out.println("O peixe esta nadando");
	}

	@Override
	public void alimentar() {
		System.out.println("O peixe esta se alimentando");
	}

	@Override
	public void emitirSom() {
		System.out.println("O peixe nao esta emitindo um som");
	}

	public void soltarBolha() {
		System.out.println("O peixe esta soltando bolhas");
	}

	// Getters & Setters

	public String getNome() {
		return Nome;
	}

	public void setNome(String nome) {
		Nome = nome;
	}
}
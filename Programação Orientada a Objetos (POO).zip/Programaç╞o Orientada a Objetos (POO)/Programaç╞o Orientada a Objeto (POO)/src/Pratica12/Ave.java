package Exercicio14;

public class Ave extends Animal {

	// Atributos

	private String corPena;

	// Metodos

	@Override
	public void locomover() {
		System.out.println("-");
	}

	@Override
	public void alimentar() {
		System.out.println("A ave esta comendo frutas");
	}

	@Override
	public void emitirSom() {
		System.out.println("A ave esta emitindo um som");
	}

	public void fazerNinho() {
		System.out.println("A ave esta construindo ninho");
	}

	public void voar() {
		System.out.println("A ave esta voando");	
	}
	
	// Getters & Setters

	public String getCorPena() {
		return corPena;
	}

	public void setCorPena(String corPena) {
		this.corPena = corPena;
	}
}
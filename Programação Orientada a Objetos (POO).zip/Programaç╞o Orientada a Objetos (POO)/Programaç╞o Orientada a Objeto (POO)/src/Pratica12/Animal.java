package Exercicio14;

public abstract class Animal {

	// Atributos

	protected float peso;
	protected int idade;
	protected int membros;

	// Metodos

	public abstract void locomover();

	public abstract void alimentar();

	public abstract void emitirSom();

	// Getters & Setters

	public float getPeso() {
		return peso;
	}

	public void setPeso(float peso) {
		this.peso = peso;
	}

	public int idade() {
		return idade;
	}

	public void idade(int idade) {
		this.idade = idade;
	}

	public int getMembros() {
		return membros;
	}

	public void setMembros(int membros) {
		this.membros = membros;
	}
}
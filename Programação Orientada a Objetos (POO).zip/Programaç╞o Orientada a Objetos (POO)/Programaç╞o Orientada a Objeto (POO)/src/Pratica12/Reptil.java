package Exercicio14;

public class Reptil extends Animal {

	// Atributos

	private String corEscama;

	// Metodos

	@Override
	public void locomover() {
		System.out.println("O reptil esta rastejando");
	}

	@Override
	public void alimentar() {
		System.out.println("O reptil esta comendo vegetais");
	}

	@Override
	public void emitirSom() {
		System.out.println("O reptil esta emitindo um som");
	}

	// Getters & Setters

	public String getCorEscama() {
		return corEscama;
	}

	public void setCorEscama(String corEscama) {
		this.corEscama = corEscama;
	}
}
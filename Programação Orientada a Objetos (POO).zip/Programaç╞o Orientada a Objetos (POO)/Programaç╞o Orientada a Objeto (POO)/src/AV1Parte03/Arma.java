package Exercicio15AV1Part3;

public class Arma {

	// Metodos
	
	private int potencia;

	// Getters & Setters
	
	public int getPot() {
		return potencia;
	}

	public void setPot(int pot) {
		this.potencia = pot;
	}
}
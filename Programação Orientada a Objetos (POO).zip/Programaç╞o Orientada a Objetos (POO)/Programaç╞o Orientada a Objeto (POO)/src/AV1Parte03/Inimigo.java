package Exercicio15AV1Part3;

public class Inimigo extends Pessoa {

	// Constructor
	
	public Inimigo(String sexo, Arma arma, String nome, int hp, int mp, int pot) {
		super(sexo, arma, nome, hp, mp, pot);
	}

	// Metodos
	
	public void atakf(Pessoa alvo) {
		int hpAtualDoAlvo = alvo.getHp();
		alvo.setHp(alvo.getHp() - 350);
		System.out.println("Ataque realizado com sucesso");
	}

	public void atakm(Pessoa alvo) {
		int hpAtualDoAlvo = alvo.getHp();
		alvo.setHp(alvo.getHp() - 400);
		System.out.println("Ataque realizado com sucesso");
	}

	public void imprimir() {
		System.out.println("A vida atual È: " + this.getHp());

	}

	public void atacarespadachim() {

	}
}
package AV3Final;

public class Titulo {

	// Atributos
	public int numeroDoTitulo;

	//Encapsulamento
	public int getNumeroDoTitulo() {
		return numeroDoTitulo ;
	}

	public void setNumeroDoTitulo(int numeroDoTitulo) {
		this.numeroDoTitulo = numeroDoTitulo;
	}
}
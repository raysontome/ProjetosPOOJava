package AV3Final;

public interface Eleito {

	//Funcoes
	public void fazerFestaDePosse();
	
	public void sumir();	
}
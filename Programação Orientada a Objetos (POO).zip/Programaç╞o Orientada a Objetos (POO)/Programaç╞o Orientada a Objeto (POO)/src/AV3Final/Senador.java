package AV3Final;

public class Senador implements Campanha, Eleito {

	// Atributos
	public int numeroDoCandidato;
	public String nomeVerdadeiro, nomeDeGuerra;

	public Senador(int i, String string, String string2) {
	}

	// Encapsulamento
	public int getNumeroDoCandidato() {
		return numeroDoCandidato;
	}

	public void setNumeroDoCandidato(int numeroDoCandidato) {
		this.numeroDoCandidato = numeroDoCandidato;
	}

	public String getNomeVerdadeiro() {
		return nomeVerdadeiro;
	}

	public void setNomeVerdadeiro(String nomeVerdadeiro) {
		this.nomeVerdadeiro = nomeVerdadeiro;
	}

	public String getNomeDeGuerra() {
		return nomeDeGuerra;
	}

	public void setNomeDeGuerra(String nomeDeGuerra) {
		this.nomeDeGuerra = nomeDeGuerra;
	}

	// Funcoes da Interface Campanha
	@Override
	public void darRisadaFalsa() {
		System.out.println("rsrs!");
	}

	@Override
	public void cantarJingle() {
		System.out.println("Cantando Jingle!");
	}

	// Funcoes da Interface Eleito
	@Override
	public void fazerFestaDePosse() {
		System.out.println("Festa de Posse do Senador eleito!");
	}

	@Override
	public void sumir() {
		System.out.println("Festa do Sumico do Senador eleito!");
	}
}
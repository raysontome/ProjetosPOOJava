package AV3Final;

public class RotinaPrincipalEleicao {

	public static void main(String[] args) {

		//Instanciando os objetos
		
		Presidente Marina = new Presidente(10, "Marina", "Lima");
		
		Senador Pedro = new Senador(20, "Pedro", "Benicio");

		Deputado Deputado = new Deputado(30, "Afonso", "Lima");

	}
}
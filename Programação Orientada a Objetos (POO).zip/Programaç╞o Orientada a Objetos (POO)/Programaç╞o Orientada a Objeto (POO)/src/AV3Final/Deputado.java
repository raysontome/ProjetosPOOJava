package AV3Final;

public class Deputado implements Campanha, Eleito {

	// Atributos
	public int numeroDoCandidato;
	public String nomeVerdadeiro, nomeDeGuerra;

	public Deputado(int i, String string, String string2) {
	}

	// Encapsulamento
	public int getNumeroDoCandidato() {
		return numeroDoCandidato;
	}

	public void setNumeroDoCandidato(int numeroDoCandidato) {
		this.numeroDoCandidato = numeroDoCandidato;
	}

	public String getNomeVerdadeiro() {
		return nomeVerdadeiro;
	}

	public void setNomeVerdadeiro(String nomeVerdadeiro) {
		this.nomeVerdadeiro = nomeVerdadeiro;
	}

	public String getNomeDeGuerra() {
		return nomeDeGuerra;
	}

	public void setNomeDeGuerra(String nomeDeGuerra) {
		this.nomeDeGuerra = nomeDeGuerra;
	}

	// Funcoes da Interface Campanha
	@Override
	public void darRisadaFalsa() {		
		System.out.println("kkkkkkk!");
	}

	@Override
	public void cantarJingle() {	
		System.out.println("...Jingle bell, Jingle bell!...");
	}
	
	// Funcoes da Interface Eleito
	@Override
	public void fazerFestaDePosse() {
		System.out.println("Festa do povao com o Deputado eleito!");
	}

	@Override
	public void sumir() {		
		System.out.println("Festa do povao em comemoracao do sumico do Deputado eleito!");
	}
}
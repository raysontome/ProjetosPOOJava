package AV3Final;

public class Identidade extends Titulo {

	// Atributos
	public String nomeCompleto;

	//Encapsulamento
	public String getNomeCompleto() {
		return nomeCompleto ;
	}

	public void setNomeCompleto(String nomeCompleto) {
		this.nomeCompleto = nomeCompleto;
	}
}
package AV3Final;


public interface Campanha {

	//Funcoes
	public void darRisadaFalsa();
	
	public void cantarJingle();
	
}
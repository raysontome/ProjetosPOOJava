package AV3Final;

public class Voto {

	// Constructor
	public Voto(Titulo titulo, Presidente presidente) {
		System.out.println("DIM, DIM, DIM! Voto realizado!");

	}

	public Voto(Titulo titulo, Presidente presidente, Senador senador) {
		System.out.println("DONG, DONG, DONG! Voto realizado!");

	}

	public Voto(Titulo titulo, Presidente presidente, Senador senador, Deputado deputado) {
		System.out.println("BLIM, BLIM, BLIM! Voto realizado!");

	}

}
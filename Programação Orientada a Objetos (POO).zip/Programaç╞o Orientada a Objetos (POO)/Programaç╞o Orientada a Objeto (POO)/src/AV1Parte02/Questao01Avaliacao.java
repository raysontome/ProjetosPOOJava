package AV1Parte02;

public class Questao01Avaliacao {

	// Atributos

	public String nomeAluno, matriculaAluno;
	private String questao1, questao2, questao3;

	// Constructor

	public Questao01Avaliacao(String nomeAluno, String matriculaAluno) {
		this.setMatriculaAluno(matriculaAluno);
		this.setNomeAluno(nomeAluno);
	}

	// Metodos

	public void responderQuestao1() {

		this.setQuestao1("B - Heranca");
		System.out.println("Resposta Questao 01: " + this.getQuestao1());

	}

	public void responderQuestao2() {

		this.setQuestao2("E - Encapsulamento");
		System.out.println("Resposta Questao 02: " + this.getQuestao2());
	}

	public void responderQuestao3() {

		this.setQuestao3("B - II e III");
		System.out.println("Resposta Questao 03: " + this.getQuestao3());
	}

	public void imprimirGabarito() {

		System.out.println("Segue o gabarito completo: ");
		System.out.println("ITEM 1: " + this.getQuestao1());
		System.out.println("ITEM 2: " + this.getQuestao2());
		System.out.println("ITEM 3: " + this.getQuestao3());
	}

	// Getters & Setters

	public String getQuestao1() {
		return questao1;
	}

	public void setQuestao1(String questao1) {
		this.questao1 = questao1;
	}

	public String getQuestao2() {
		return questao2;
	}

	public void setQuestao2(String questao2) {
		this.questao2 = questao2;
	}

	public String getQuestao3() {
		return questao3;
	}

	public void setQuestao3(String questao3) {
		this.questao3 = questao3;
	}

	public String getNomeAluno() {
		return nomeAluno;
	}

	public void setNomeAluno(String nomeAluno) {
		this.nomeAluno = nomeAluno;
	}

	public String getMatriculaAluno() {
		return matriculaAluno;
	}

	public void setMatriculaAluno(String matriculaAluno) {
		this.matriculaAluno = matriculaAluno;
	}
}
package AV1Parte02;

public class Questao02Particula {

	public double PosicaoInicial, VelocidadeInicial, Aceleracao;

	// Constructor

	public Questao02Particula(double posicaoInicial, double velocidadeInicial, double aceleracao) {
		PosicaoInicial = posicaoInicial;
		VelocidadeInicial = velocidadeInicial;
		Aceleracao = aceleracao;
	}

	// Metodos

	public void calcularPosicao(double tempo) {
		double posicao;
		posicao = getPosicaoInicial() + getVelocidadeInicial() * tempo + (Aceleracao * tempo * tempo) / 2;
		System.out.println("Sua posicao e: " + posicao);

	}

	public void calcularVelocidade(double tempo) {
		double posicao;

		VelocidadeInicial = getVelocidadeInicial() + Aceleracao * tempo;
		System.out.println("Sua velocidade e: " + VelocidadeInicial);
	}

	// Getters & Setters

	public double getPosicaoInicial() {
		return PosicaoInicial;
	}

	public void setPosicaoInicial(double posicaoInicial) {
		PosicaoInicial = posicaoInicial;
	}

	public double getVelocidadeInicial() {
		return VelocidadeInicial;
	}

	public void setVelocidadeInicial(double velocidadeInicial) {
		VelocidadeInicial = velocidadeInicial;
	}

	public double getAceleracao() {
		return Aceleracao;
	}

	public void setAceleracao(double aceleracao) {
		Aceleracao = aceleracao;
	}
}
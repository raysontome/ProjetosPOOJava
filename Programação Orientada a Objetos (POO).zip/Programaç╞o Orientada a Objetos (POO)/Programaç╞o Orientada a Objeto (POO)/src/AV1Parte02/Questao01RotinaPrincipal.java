package AV1Parte02;

public class Questao01RotinaPrincipal {

	public static void main(String[] args) {

		// Instanciando novo objeto

		Questao01Avaliacao AV = new Questao01Avaliacao("RAYSONTOME", "1523404");

		// Rotina Principal

		AV.responderQuestao1();
		AV.responderQuestao2();
		AV.responderQuestao3();
		AV.imprimirGabarito();
	}
}
package AV1Parte02;

public class Questao02RotinaPrincipal {

	public static void main(String[] args) {

		// Instanciando novo objeto

		Questao02Particula Part = new Questao02Particula(20, 30, 30);

		// Rotina Principal

		Part.calcularPosicao(20);

		Part.calcularVelocidade(20);
	}
}
package Exercicio17;

import java.util.Random;

public class Luta {

	// Metodos

	private void lutar() {
	}

	private void apresentar() {

	}
}
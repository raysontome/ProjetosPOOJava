package Exercicio17;

public abstract interface Boxe {

	// Metodos

	public void morderOrelha();

	public void empurrar();
}
package Exercicio17;

public class Lutador {

	// Atributos

	private int Peso;
	private String Altura;
	private String Nome;
	private String Nacionalidade;
	private String Categoria;
	private int NVitorias; // 0
	private int NDerrotas; // 0
	private int NKO; // 0

	// Constructor

	public Lutador(int peso, int altura, String nome, String nacionalidade, String categoria, int nVitorias,
			int nDerrotas, int nKO) {
		Peso = 70;
		Altura = "1.50";
		Nome = "Lutador";
		Nacionalidade = "Brasileiro";
		Categoria = categoria;
		NVitorias = 0;
		NDerrotas = 0;
		NKO = 0;
	}

	// Metodos

	private void calcCategoria() {

	}

	// Getters & Setters

	public int getPeso() {
		return Peso;
	}

	public void setPeso(int peso) {
		Peso = peso;
	}

	public String getNome() {
		return Nome;
	}

	public void setNome(String nome) {
		Nome = nome;
	}

	public String getAltura() {
		return Altura;
	}

	public void setAltura(String altura) {
		Altura = altura;
	}

	public String getNacionalidade() {
		return Nacionalidade;
	}

	public void setNacionalidade(String nacionalidade) {
		Nacionalidade = nacionalidade;
	}

	public String getCategoria() {
		return Categoria;
	}

	public void setCategoria(String categoria) {
		Categoria = categoria;
	}

	public int getNVitorias() {
		return NVitorias;
	}

	public void setNVitorias(int nVitorias) {
		NVitorias = nVitorias;
	}

	public int getNDerrotas() {
		return NDerrotas;
	}

	public void setNDerrotas(int nDerrotas) {
		NDerrotas = nDerrotas;
	}

	public int getNKO() {
		return NKO;
	}

	public void setNKO(int nKO) {
		NKO = nKO;
	}
}
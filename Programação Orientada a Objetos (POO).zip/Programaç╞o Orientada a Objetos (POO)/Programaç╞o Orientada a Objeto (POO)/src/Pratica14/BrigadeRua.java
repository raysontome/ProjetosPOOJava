package Exercicio17;

public abstract interface BrigadeRua {

	// Metodos

	public void xingarMae();

	public void cadeirada();
}
package Exercicio17;

public abstract interface Karate {

	// Metodos

	public void gritar();

	public void quebrarTauba();
}
package Exercicio17;

public abstract interface Judo {

	// Metodos

	public void derrubar();

	public void quebrarTudo();
}
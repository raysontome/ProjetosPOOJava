package Exercicio17;

public abstract interface MuayThai {

	// Metodos

	public void canelada();

	public void bicuda();
}
package Exercicio09;

public class RotinaPrincipal {
	public static void main(String[] args) {

		// Logo Agenda

		System.out.println("# Agenda de Clientes para sorteios! #");
		System.out.println("-----------------------------------------------------------------------------------");

		// Instanciacao da agenda com os 6 clientes sorteados

		Agenda Cliente = new Agenda(null, 0, 0);

		// Informacoes dos sorteados por ordem de 1 a 6

		System.out.println("As informacoes dos contados da Agenda que serao sorteados para a promocao NET foram: ");
		Agenda C1 = new Agenda("Rayson", 996766931, 603977571);
		System.out.println("INF. do primeiro contato: " + C1.getNome() + "/" + C1.getTelefone() + "/" + C1.getCPF());

		Agenda C2 = new Agenda("Priscila", 996766932, 603977572);
		System.out.println("INF. do segundo contato: " + C2.getNome() + "/" + C2.getTelefone() + "/" + C2.getCPF());

		Agenda C3 = new Agenda("Rebeca", 996766933, 603977573);
		System.out.println("INF. do terceiro contato: " + C3.getNome() + "/" + C3.getTelefone() + "/" + C3.getCPF());

		Agenda C4 = new Agenda("Raquel", 996766934, 603977574);
		System.out.println("INF. do quarto contato: " + C4.getNome() + "/" + C4.getTelefone() + "/" + C4.getCPF());

		Agenda C5 = new Agenda("Debora", 996766935, 603977575);
		System.out.println("INF. do quinto contato: " + C5.getNome() + "/" + C5.getTelefone() + "/" + C5.getCPF());

		Agenda C6 = new Agenda("Pedro", 996766936, 603977576);
		System.out.println("INF. do sexto contato: " + C6.getNome() + "/" + C6.getTelefone() + "/" + C6.getCPF());
		System.out.println("-----------------------------------------------------------------------------------");

		// Informacoes do Sorteado entre os 6 contatos mencionados na Agenda

		System.out.println("Exibir os sorteados que ganharam a promocao NET: ");
		C1.novoSorteado();
		System.out.println("-----------------------------------------------------------------------------------");

		// Informacoes com a remocao dos sorteados por ordem de 1 a 6

		System.out.println("Exibir os sorteados que foram removidos da Agenda: ");
		C2.removeSorteado();
		C3.removeSorteado();
		C4.removeSorteado();
		C5.removeSorteado();
		C6.removeSorteado();
		System.out.println("-----------------------------------------------------------------------------------");

		// Impressao dos dados de todas as pessoas da Agenda
		System.out.println("Exibir os dados dos clientes sorteados da Agenda: ");
		System.out.println("-----------");
		C1.ImprimirAgenda();
		System.out.println("-----------");
		C2.ImprimirAgenda();
		System.out.println("-----------");
		C3.ImprimirAgenda();
		System.out.println("-----------");
		C4.ImprimirAgenda();
		System.out.println("-----------");
		C5.ImprimirAgenda();
		System.out.println("-----------");
		C6.ImprimirAgenda();
		System.out.println("-----------");
		System.out.println("-----------------------------------------------------------------------------------");
		System.out.println("FIM!");
	}
}
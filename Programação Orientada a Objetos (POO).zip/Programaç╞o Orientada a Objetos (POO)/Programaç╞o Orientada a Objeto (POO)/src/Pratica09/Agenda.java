package Exercicio09;

import java.util.ArrayList;
import java.util.Scanner;

public class Agenda {

	// Atributos

	private String Nome;
	private int CPF, Telefone, TotalAgenda = 10;

	// Constructor

	public Agenda(String nome, int telefone, int CPF) {
		this.Nome = nome;
		this.Telefone = telefone;
		this.CPF = CPF;
	}

	// Metodos

	public String getNome() {
		return Nome;
	}

	public void setNome(String nome) {
		Nome = nome;
	}

	public int getTelefone() {
		return Telefone;
	}

	public void setTelefone(int telefone) {
		Telefone = telefone;
	}

	public int getCPF() {
		return CPF;
	}

	public void setCPF(int cPF) {
		CPF = cPF;
	}

	// Metodos

	public void novoSorteado() {
		System.out.println(
				"Parabens, " + this.getNome() + " voce ganhou a promocao! " + "" + "Segue suas informacoes pessoais: "
						+ "CPF: " + this.getCPF() + "  " + "Telefone: " + this.getTelefone());
	}

	public void removeSorteado() {
		System.out.println("Removido: " + this.getNome());
	}

	public void ImprimirAgenda() {
		System.out.println("Nome " + this.getNome());
		System.out.println("CPF: " + this.getCPF());
		System.out.println("Telefone: " + this.getTelefone());
	}
}
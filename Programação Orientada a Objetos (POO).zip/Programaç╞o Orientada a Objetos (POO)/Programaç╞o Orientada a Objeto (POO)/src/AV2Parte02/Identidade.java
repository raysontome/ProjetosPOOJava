package Exercicio22AV2Part02;

abstract class Identidade {

	// Atributos

	private int numId, anoDeNas;
	private String nomeCompleto;

	// Getters & Setters

	public int getNumId() {
		return numId;
	}

	public void setNumId(int numId) {
		this.numId = numId;
	}

	public int getAnoDeNas() {
		return anoDeNas;
	}

	public void setAnoDeNas(int anoDeNas) {
		this.anoDeNas = anoDeNas;
	}

	public String getNomeCompleto() {
		return nomeCompleto;
	}

	public void setNomeCompleto(String nomeCompleto) {
		this.nomeCompleto = nomeCompleto;
	}

	// Constructor

	public Identidade(int numId, int anoDeNas, String nomeCompleto) {

		this.numId = numId;
		this.anoDeNas = anoDeNas;
		this.nomeCompleto = nomeCompleto;
	}
}
package Exercicio22AV2Part02;

public class RotinaPrincipal {

	public static void main(String[] args) {

		Habilitacao H[] = new Habilitacao[3];

		H[0] = new Habilitacao(01, 2000, "RAYSON");
		H[0].setEndereco("Praia do Futuro");
		H[1] = new Habilitacao(02, 2001, "PEDRO");
		H[1].setEndereco("Aldeota");
		H[2] = new Habilitacao(03, 2002, "RENATO");
		H[2].setEndereco("Centro");

		Multa M01 = new Multa(H[2], 4);
		Multa M02 = new Multa(H[3], 7, H[1], 6);
		Multa M03 = new Multa(H[0], 6, H[0], 8);
	}
}
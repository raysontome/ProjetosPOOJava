package Exercicio22AV2Part02;

public class Multa {

	public Multa(Habilitacao h01, int pontos) {

		double valor01;

		valor01 = h01.getNumDePontos() * 54.25;
		h01.setDivida(true);
		h01.setNumDePontos(pontos);

		System.out.println("Valor da multa é de R$: " + valor01);
		System.out.println("Endereco da multa é de: " + h01.getEndereco());
		System.out.println("Nome do motorista é: " + h01.getNomeCompleto());
		System.out.println("Total de pontos da habilitacao: " + h01.getNumDePontos());
		if (h01.isDivida() == true) {
			System.out.println("Cidadao com CPF inadiplente!");

		} else {
			System.out.println("Cidadao com CPF sem restricoes!");
		}
	}

	public Multa(Habilitacao h01, int pontos01, Habilitacao h02, int pontos02) {

		double valor01;
		double valor02;

		valor01 = h01.getNumDePontos() * 54.25;
		valor02 = h02.getNumDePontos() * 54.25;

		h01.setDivida(true);
		h01.setNumDePontos(pontos01);
		h02.setDivida(true);
		h02.setNumDePontos(pontos02);

		System.out.println("Valor da multa é de R$: " + valor01);
		System.out.println("Endereco da multa é: " + h01.getEndereco());
		System.out.println("Nome do motorista é: " + h01.getNomeCompleto());
		System.out.println("Total de pontos da habilitacao: " + h01.getNumDePontos());

		System.out.println("Valor da multa é de R$: " + valor02);
		System.out.println("Endereco da multa é: " + h02.getEndereco());
		System.out.println("Nome do motorista é: " + h02.getNomeCompleto());
		System.out.println("Total de pontos da habilitacaoo: " + h02.getNumDePontos());
		if (h01.isDivida() == true) {
			System.out.println("Cidadao com CPF inadiplente!");

		} else {
			System.out.println("Cidadao com CPF sem restricoes!");
		}
	}

	public Multa(Habilitacao h01, int pontos01, Habilitacao h02, int pontos02, Habilitacao h03, int pontos03) {

		double valor01;
		double valor02;
		double valor03;

		h01.setDivida(true);
		h01.setNumDePontos(pontos01);
		h02.setDivida(true);
		h02.setNumDePontos(pontos02);
		h03.setDivida(true);
		h03.setNumDePontos(pontos03);

		valor01 = h01.getNumDePontos() * 54.25;
		valor02 = h02.getNumDePontos() * 54.25;
		valor03 = h03.getNumDePontos() * 54.25;

		System.out.println("Valor da multa é de R$: " + valor01);
		System.out.println("Endereco da multa é: " + h01.getEndereco());
		System.out.println("Nome do motorista é: " + h01.getNomeCompleto());
		System.out.println("Total de pontos da habilitacao: " + h01.getNumDePontos());

		System.out.println("Valor da multa é de R$: " + valor02);
		System.out.println("Endereco da multa é: " + h02.getEndereco());
		System.out.println("Nome do motorista é: " + h02.getNomeCompleto());
		System.out.println("Total de pontos da habilitacao: " + h02.getNumDePontos());

		System.out.println("Valor da multa é de R$: " + valor03);
		System.out.println("Endereco da multa é: " + h03.getEndereco());
		System.out.println("Nome do motorista é: " + h03.getNomeCompleto());
		System.out.println("Total de pontos da habilitacao: " + h03.getNumDePontos());
		if (h01.isDivida() == true) {
			System.out.println("Cidadao com CPF inadiplente!");

		} else {
			System.out.println("Cidadao com CPF sem restricoes!");
		}
	}
}
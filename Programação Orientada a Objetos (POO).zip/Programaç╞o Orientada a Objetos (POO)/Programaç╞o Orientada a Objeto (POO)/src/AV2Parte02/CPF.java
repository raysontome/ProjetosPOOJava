package Exercicio22AV2Part02;

public class CPF extends Identidade {

	// Constructor

	public CPF(int numId, int anoDeNas, String nomeCompl) {
		super(numId, anoDeNas, nomeCompl);
		this.numCpf = numCpf;
		this.divida = divida;

	}

	// Atributos

	private int numCpf;
	private boolean divida;

	// Getters & Setters

	public boolean isDivida() {
		return divida;
	}

	public void setDivida(boolean divida) {
		this.divida = divida;
	}

	public int getNumCpf() {
		return numCpf;
	}

	public void setNumCpf(int numCpf) {
		this.numCpf = numCpf;
	}
}
package Exercicio22AV2Part02;

public class Habilitacao extends CPF {

	// Constructor

	public Habilitacao(int numId, int anoDeNas, String nomeCompleto) {
		super(numId, anoDeNas, nomeCompleto);
		this.endereco = endereco;
		this.numDePontos = 0;
	}

	// Atributos

	private String endereco;
	private int numDePontos;

	// Getters & Setters

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public int getNumDePontos() {
		return numDePontos;
	}

	public void setNumDePontos(int numDePontos) {
		this.numDePontos = numDePontos;
	}
}
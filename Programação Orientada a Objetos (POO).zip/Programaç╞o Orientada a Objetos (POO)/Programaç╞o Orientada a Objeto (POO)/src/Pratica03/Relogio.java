package Exercicio03;

public class Relogio {

	// Atributos

	private String pulseira;
	private String carcaca;
	private int hora;
	private int minuto;
	private int bateria = 100;

	// Getters & Setters

	public String getPulseira() {
		return pulseira;
	}

	public void setPulseira(String pulseira) {
		this.pulseira = pulseira;
	}

	public String getCarcaca() {
		return carcaca;
	}

	public void setCarcaca(String carcaca) {
		this.carcaca = carcaca;
	}

	private int getHora() {
		return hora;
	}

	private void setHora(int hora) {
		this.hora = hora;
	}

	private int getMinuto() {
		return minuto;
	}

	private void setMinuto(int minuto) {
		this.minuto = minuto;
	}

	private int getBateria() {
		return bateria;
	}

	private void setBateria(int bateria) {
		this.bateria = bateria;
	}

	// Metodos

	private void incremMinuto() {
		setMinuto(getMinuto() + 1);
		if (getMinuto() == 60) {
			setMinuto(0);
			incremHora();
		}
	}

	private void incremHora() {
		setHora(getHora() + 1);
		if (getHora() == 24) {
			setHora(0);
		}
	}

	private void cargaBateria() {
		setBateria(getBateria() - 1);
		if (getBateria() < 1) {
			System.out.println("ERRO: A bateria precisa ser trocada!");
		}
	}

	public void consultarHorario() {
		System.out.println("Hora:" + getHora());
		System.out.println("Minuto:" + getMinuto());
		cargaBateria();
		incremMinuto();
	}

	public void definirHorario(int H, int M) {
		setHora(H);
		setMinuto(M);
	}
}
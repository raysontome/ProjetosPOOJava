package Pratica01;

public class Pessoa02 {

	public static void main(String[] args) {

		// Instanciando os novos objetos

		ClassePrincipal Aluno1 = new ClassePrincipal();

		Aluno1.matricula = 01;
		Aluno1.nome = "Rayson";
		Aluno1.professor = "Alzir";
		Aluno1.aula = "BIO";
		Aluno1.mae = "Maria";
		Aluno1.datadenascimento = 1994;

		Aluno1.calculoidade();
		Aluno1.imprimir();

		ClassePrincipal Aluno2 = new ClassePrincipal();

		Aluno2.matricula = 02;
		Aluno2.nome = "Priscila";
		Aluno1.professor = "Alzir";
		Aluno1.aula = "BIO";
		Aluno1.mae = "lUZIA";
		Aluno2.datadenascimento = 1984;
		Aluno2.calculoidade();
		Aluno2.imprimir();

		ClassePrincipal aluno3 = new ClassePrincipal();

		aluno3.matricula = 03;
		aluno3.nome = "Pedro";
		Aluno1.professor = "Alzir";
		Aluno1.aula = "BIO";
		Aluno1.mae = "Joana";
		aluno3.datadenascimento = 1970;
		aluno3.calculoidade();
		aluno3.imprimir();

		ClassePrincipal aluno4 = new ClassePrincipal();

		aluno4.matricula = 04;
		aluno4.nome = "Jefferson";
		Aluno1.professor = "Alzir";
		Aluno1.aula = "BIO";
		Aluno1.mae = "Maria";
		aluno4.datadenascimento = 1999;
		aluno4.calculoidade();
		aluno4.imprimir();

		ClassePrincipal aluno5 = new ClassePrincipal();

		aluno5.matricula = 05;
		aluno5.nome = "Ana Raquel";
		Aluno1.professor = "Alzir";
		Aluno1.aula = "BIO";
		Aluno1.mae = "Jaiza";
		aluno5.datadenascimento = 1998;
		aluno5.calculoidade();
		aluno5.imprimir();

		ClassePrincipal aluno6 = new ClassePrincipal();

		aluno6.matricula = 06;
		aluno6.nome = "Jardel";
		Aluno1.professor = "Alzir";
		Aluno1.aula = "BIO";
		Aluno1.mae = "Antonieta";
		aluno6.datadenascimento = 1985;
		aluno6.calculoidade();
		aluno6.imprimir();
	}
}
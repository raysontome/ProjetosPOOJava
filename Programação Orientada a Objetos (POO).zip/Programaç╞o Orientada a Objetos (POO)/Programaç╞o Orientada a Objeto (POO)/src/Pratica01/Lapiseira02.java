package Pratica01;

public class Lapiseira02 {

	public class lapiseira2 {

		public void main(String[] args) {

			// Instanciando os objetos

			Lapiseira01 L1 = new Lapiseira01();

			// Definindo valores

			L1.cor = "LILAS";
			L1.ponta = 0.5;
			L1.Prontaescrever = true;
			L1.escrever();

			Lapiseira01 L2 = new Lapiseira01();

			L2.cor = "blue";
			L2.ponta = 0.5;
			L2.Prontaescrever = false;
			L2.escrever();
		}
	}
}
package Pratica01;

public class Pessoa01 {

	public static void main(String[] args) {

		// Instanciando os novos objetos

		ClassePrincipal cliente1 = new ClassePrincipal();

		cliente1.matricula = 01;
		cliente1.nome = "Rayson";
		cliente1.altura = 1.60f;
		cliente1.datadenascimento = 1994;
		cliente1.peso = 99f;
		cliente1.calculoidade();
		cliente1.imprimir();
		cliente1.calculoimc();

		ClassePrincipal cliente2 = new ClassePrincipal();

		cliente2.matricula = 02;
		cliente2.nome = "Priscila";
		cliente2.altura = 1.80f;
		cliente2.datadenascimento = 1984;
		cliente2.peso = 100f;
		cliente2.calculoidade();
		cliente2.imprimir();
		cliente2.calculoimc();

		ClassePrincipal cliente3 = new ClassePrincipal();

		cliente3.matricula = 03;
		cliente3.nome = "Pedro";
		cliente3.altura = 1.99f;
		cliente3.datadenascimento = 1970;
		cliente3.peso = 100f;
		cliente3.calculoidade();
		cliente3.imprimir();
		cliente3.calculoimc();

		ClassePrincipal cliente4 = new ClassePrincipal();

		cliente4.matricula = 04;
		cliente4.nome = "Jefferson";
		cliente4.altura = 2.10f;
		cliente4.datadenascimento = 1999;
		cliente4.peso = 120f;
		cliente4.calculoidade();
		cliente4.imprimir();
		cliente4.calculoimc();

		ClassePrincipal cliente5 = new ClassePrincipal();

		cliente5.matricula = 05;
		cliente5.nome = "Ana Raquel";
		cliente5.altura = 1.90f;
		cliente5.datadenascimento = 1998;
		cliente5.peso = 77f;
		cliente5.calculoidade();
		cliente5.imprimir();
		cliente5.calculoimc();

		ClassePrincipal cliente6 = new ClassePrincipal();

		cliente6.matricula = 06;
		cliente6.nome = "Jardel";
		cliente6.altura = 1.55f;
		cliente6.datadenascimento = 1985;
		cliente6.peso = 150f;
		cliente6.calculoidade();
		cliente6.imprimir();
		cliente6.calculoimc();
	}
}
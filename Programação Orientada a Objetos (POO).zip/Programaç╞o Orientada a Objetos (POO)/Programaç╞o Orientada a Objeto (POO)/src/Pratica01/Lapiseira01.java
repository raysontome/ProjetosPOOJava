package Pratica01;

public class Lapiseira01 {

	// Atributos

	double ponta;
	boolean Prontaescrever;
	String cor;

	// Metodos

	void sacarPonta() {
		Prontaescrever = true;
	}

	void escrever() {
		if (Prontaescrever) {
			System.out.println("Estou escrevendo!");
		} else {
			System.out.println("Erro!");
		}
	}
}
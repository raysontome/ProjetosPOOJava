package Pratica01;

public class ClassePrincipal {

	// Atributos

	String nome, mae, professor, aula;
	float datadenascimento, idade, imc, altura, peso, presenca;
	double matricula;
	int escolaridade;

	// Metodos

	void calculoidade() {

		idade = (2018 - datadenascimento);

	}

	void imprimir() {

		System.out.println("Os seus dados sao: \t");
		if (nome != null) {
			System.out.println("Seu nome: \t" + nome);
		}
		if (altura != 0) {
			System.out.println("Sua altura: \t" + altura);
		}
		System.out.println("Sua idade: \t" + idade);
		System.out.println("Sua matricula: \t" + matricula);

	}

	void calculoimc() {
		imc = peso / (altura * altura);
		System.out.println("Seu IDM È " + imc);

	}
}
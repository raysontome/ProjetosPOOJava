package Exercicio04;

public class Pessoa {
	public static void main(String[] args) {

		// Instanciando o novo objeto
		ContaBanco P1 = new ContaBanco();

		// Rotina Principal

		P1.setNumConta(01);
		P1.setDono("Rayson Tome");
		P1.abrirConta("Conta Corrente");
		P1.sacar(100);
		P1.fecharConta();

		ContaBanco P2 = new ContaBanco();
		P2.setNumConta(02);
		P2.setDono("Priscila Levi");
		P2.abrirConta("Conta Poupanca");
		P2.sacar(300);
		P2.fecharConta();

		P1.estadoAtual();
		P2.estadoAtual();
	}
}